/* FM1 Tonic preview UI. Panel geometry follows Felucca's GPL-3.0 FM-1 emulator. */
"use strict";

const NS = "http://www.w3.org/2000/svg";
const $ = (q) => document.querySelector(q);
const svg = $("#panel"), device = $("#device"), canvas = $("#screen"), c = canvas.getContext("2d");
const L = {
  w: 1000, h: 624, screen: [292, 44, 256],
  knobs: [[105, 100, 24], [215, 100, 24], [105, 205, 24], [215, 205, 24], [610, 100, 22], [714, 100, 22], [818, 100, 22], [922, 100, 22]],
  trays: [[50, 250, 220, 50], [568, 160, 400, 140]],
  oct: [[60, 258, 90, 34], [170, 258, 90, 34]],
  grid: [582, 174, 54, 48, 63, 62], keybed: [36, 332, 928, 256],
};
const WHITE = [0, 2, 4, 6, 7, 9, 11, 12, 14, 16, 18, 19, 21, 23, 24, 26];
const BLACK = [1, 3, 5, 8, 10, 13, 15, 17, 20, 22, 25];
const BLACK_AFTER = [0, 1, 2, 4, 5, 7, 8, 9, 11, 12, 14];
const ROW1 = ["FX", "SEL", "ENV", "LFO", "EDIT", "GLO"];
const ROW2 = ["HOME", "SAVE", "ARP", "SEQ", "PLAY", "REC"];
const KNOB_NAMES = ["MASTER", "SELECT", "PRESETS", "ALGORITHM", "KNOB 1", "KNOB 2", "KNOB 3", "KNOB 4"];
const PARAM_NAMES = ["OscWave", "OscFreq", "OscAtk", "OscDcy", "ModMode", "ModRate", "ModAmt", "NFilMod", "NFilFrq", "NFilQ", "NEnvMod", "NEnvAtk", "NEnvDcy", "Mix", "DistAmt", "EQFreq", "EQGain", "Level", "OscVel", "NVel", "ModVel"];
const PARAM_LABELS = ["WAVE", "OSC FREQ", "OSC ATK", "OSC DEC", "MOD MODE", "MOD RATE", "MOD AMT", "NOISE FILT", "NOISE FREQ", "NOISE Q", "NOISE ENV", "NOISE ATK", "NOISE DEC", "MIX", "DRIVE", "EQ FREQ", "EQ GAIN", "LEVEL", "OSC VEL", "NOISE VEL", "MOD VEL"];
const MODES = { 0: [0, 0.5, 1], 4: [0, 0.5, 1], 7: [0, 0.5, 1], 10: [0, 0.5, 1] };
const PAGE_PARAMS = {
  home: [1, 3, 12, 13], edit: [0, 1, 2, 3], lfo: [4, 5, 6, 20],
  scl: [7, 8, 9, 10], env: [2, 3, 11, 12], fx: [13, 14, 15, 16],
  mix: [17, 18, 19, 20],
};
const PAGE_NAMES = ["home", "edit", "lfo", "scl", "env", "fx", "mix"];
const PATTERN_SLOTS = "abcdefghijklmnop".split("");
const SAVE_PATTERN_SLOTS = "abcdefghijkl".split("");
const PROJECT_SLOTS = "ABCDEFGHIJKLMNOP".split("");
const DEVICE_SETTINGS = [
  { key: "project", label: "SAVE PROJECT", action: true },
  { key: "clock", label: "CLOCK MODE", values: ["INT", "EXT"] },
  { key: "noteOut", label: "NOTE OUT", values: ["ON", "OFF"] },
  { key: "midiIn", label: "MIDI CH IN", values: [...Array.from({ length: 16 }, (_, i) => String(i + 1)), "ALL"] },
  { key: "midiOut", label: "MIDI CH OUT", values: [...Array.from({ length: 16 }, (_, i) => String(i + 1)), "ALL"] },
  { key: "output", label: "OUTPUT", values: ["NORMAL", "LOUD"] },
  { key: "usbAudio", label: "USB AUDIO", values: ["YES", "NO"] },
];
const DEFAULT_DEVICE_SETTINGS = { clock: "INT", noteOut: "ON", midiIn: "1", midiOut: "1", output: "NORMAL", usbAudio: "YES" };
const DEFAULT_PATCH = {
  Name: "Tonic Drum", OscWave: "Sine", OscFreq: "440", OscAtk: "0", OscDcy: "316",
  ModMode: "Decay", ModRate: "120", ModAmt: "0", NFilMod: "BP", NFilFrq: "5000", NFilQ: "0.7",
  NEnvMod: "Exp", NEnvAtk: "0", NEnvDcy: "300", Mix: "50", DistAmt: "0", EQFreq: "1000",
  EQGain: "0", Level: "0", OscVel: "100", NVel: "100", ModVel: "0", NStereo: "Off", Output: "A", Pan: "0",
};

let S = null, P = [], bufs = [], ctx = null, master = null, shaper = null, outputGainNode = null;
let playbackPatches = [], playbackBuffers = [], playbackPattern = "";
let displayPatches = [], displayPattern = "", focusTimer = 0, focusedParamSlot = -1, focusedHomeSlot = -1;
let pat = "a", lane = 0, screen = "global", editPage = 0, playing = false, recording = false;
let cur = -1, tempo = 120, swing = 50, volume = 0.7, clip = 0, bank = 0, timer = 0, nxt = 0, stp = 0, q = [], voices = [];
let pans = Array(8).fill(0);
let selectedStep = -1, selectedLane = -1, selectedPattern = "";
let trackVolumes = Array(8).fill(1), deviceSettings = { ...DEFAULT_DEVICE_SETTINGS }, savedDeviceSettings = { ...DEFAULT_DEVICE_SETTINGS };
let settingsDirty = false, selectedDeviceSetting = 0, saveFlow = null, saveFlowTimer = 0, loadFlow = null, loadFlowTimer = 0;
let projectLoadSlot = "A", quickPatternArm = false;
let knobs = [], keys = [], buttons = [], knobDrag = new Map(), busy = false;
const DOT = "'DotGothic16', monospace";
const LCD = {
  bg: "#05080c", primary: "#e8edf0", secondary: "#a0aab1", muted: "#74818a",
  row: "#18232b", track: "#2d353a", hit: "#e8edf0", accent: "#3b7294",
  highlight: "#a9dbf1", fill: "#3f8cf0", trigAccent: "#e5483f", both: "#a66ae0", cursor: "#b8e6fa", alert: "#a9dbf1",
  knobBg: "#b8bdc0", knobInk: "#1c2a33", knobEdge: "#59666e",
};
const message = (text) => { $("#message").textContent = text; };

function el(tag, attrs, parent = svg) {
  const e = document.createElementNS(NS, tag);
  for (const [k, v] of Object.entries(attrs)) e.setAttribute(k, v);
  parent.appendChild(e);
  return e;
}
function label(parent, x, y, s, size, font = "-apple-system, Arial, sans-serif", ink = "var(--label)") {
  const t = el("text", { x, y, "text-anchor": "middle", "font-family": font, "font-size": size, "font-weight": 600, fill: ink, "letter-spacing": ".04em" }, parent);
  t.textContent = s;
  return t;
}
function button(box, name, sub, action) {
  const [x, y, w, h] = box, g = el("g", { class: "btnx" });
  g.setAttribute("role", "button"); g.setAttribute("tabindex", "0"); g.setAttribute("aria-label", sub ? `${name} ${sub}` : name);
  el("rect", { x, y, width: w, height: h, rx: 8, fill: "var(--part)", stroke: "var(--edge)", "stroke-width": 1.5, class: "face btn" }, g);
  const ink = name === "REC" ? "#ff453a" : undefined;
  if (sub) { label(g, x + w / 2, y + h / 2 - 2, name, 10.8, undefined, ink); label(g, x + w / 2, y + h / 2 + 11, sub, 9.9); }
  else label(g, x + w / 2, y + h / 2 + 4.5, name, 12.6, undefined, ink);
  if (name === "GLO") {
    let holdTimer = 0, active = false, heldAction = false;
    const clearHold = () => { clearTimeout(holdTimer); holdTimer = 0; };
    g.addEventListener("pointerdown", (e) => {
      e.preventDefault(); active = true; heldAction = false; g.classList.add("held"); g.setPointerCapture?.(e.pointerId);
      if (e.shiftKey) { heldAction = true; action?.(e, true); }
      else holdTimer = setTimeout(() => { if (active) { heldAction = true; action?.(e, true); } }, 500);
    });
    g.addEventListener("pointerup", (e) => {
      if (!active) return; active = false; clearHold();
      if (!heldAction) action?.(e, false);
      g.classList.remove("held");
    });
    for (const ev of ["pointercancel", "lostpointercapture"]) g.addEventListener(ev, () => {
      active = false; clearHold(); g.classList.remove("held");
    });
    g.addEventListener("keydown", (e) => {
      if ((e.key !== "Enter" && e.key !== " ") || e.repeat || active) return;
      e.preventDefault(); active = true; heldAction = false; g.classList.add("held");
      if (e.shiftKey) { heldAction = true; action?.(e, true); }
      else holdTimer = setTimeout(() => { if (active) { heldAction = true; action?.(e, true); } }, 500);
    });
    g.addEventListener("keyup", (e) => {
      if (!active) return; active = false; clearHold();
      if (!heldAction) action?.(e, false);
      g.classList.remove("held");
    });
    buttons.push({ g, name });
    return;
  }
  g.addEventListener("pointerdown", (e) => { e.preventDefault(); g.classList.add("held"); g.setPointerCapture?.(e.pointerId); action?.(e); });
  for (const ev of ["pointerup", "pointerleave", "pointercancel", "lostpointercapture"]) g.addEventListener(ev, () => g.classList.remove("held"));
  g.addEventListener("keydown", (e) => { if ((e.key === "Enter" || e.key === " ") && !e.repeat) { e.preventDefault(); g.classList.add("held"); action?.(e); } });
  g.addEventListener("keyup", () => g.classList.remove("held"));
  buttons.push({ g, name });
}
function build() {
  svg.innerHTML = ""; knobs = []; keys = []; buttons = [];
  el("rect", { x: 4, y: 4, width: L.w - 8, height: L.h - 8, rx: 40, fill: "var(--body)" });
  for (const [x, y, w, h] of L.trays) el("rect", { x, y, width: w, height: h, rx: 14, fill: "var(--tray)" });
  const [sx, sy, ss] = L.screen;
  el("rect", { x: sx, y: sy, width: ss, height: ss, rx: 18, fill: "#0b0b0c" });
  const inset = ss / 32;
  Object.assign(canvas.style, { left: `${(sx + inset) / L.w * 100}%`, top: `${(sy + inset) / L.h * 100}%`, width: `${(ss - 2 * inset) / L.w * 100}%`, height: `${(ss - 2 * inset) / L.h * 100}%` });
  KNOB_NAMES.forEach((name, i) => {
    const [x, y, r] = L.knobs[i], g = el("g", { class: "knob", role: "slider", tabindex: 0, "aria-label": name, "aria-valuemin": 0, "aria-valuemax": 100 });
    el("circle", { cx: x, cy: y, r: r + 5, fill: "var(--tray)" }, g);
    el("circle", { cx: x, cy: y, r, fill: "var(--part)", stroke: "var(--edge)", "stroke-width": 2 }, g);
    const ind = i === 0 ? el("line", { x1: x, y1: y - r + 5, x2: x, y2: y - r + 14, stroke: "var(--label)", "stroke-width": 3, "stroke-linecap": "round" }, g) : null;
    label(g, x, y - r - 12, name, 15.5, DOT);
    el("circle", { cx: x, cy: y, r: r + 12, fill: "transparent" }, g);
    knobs.push({ g, ind, x, y, name, val: 0, min: 0, max: 1, step: 0 });
    bindKnob(knobs[i], i);
    g.addEventListener("keydown", (e) => {
      if (!["ArrowUp", "ArrowRight", "ArrowDown", "ArrowLeft"].includes(e.key)) return;
      e.preventDefault(); turnKnob(i, e.key === "ArrowUp" || e.key === "ArrowRight" ? 8 : -8);
    });
  });
  button(L.oct[0], "OCT-", "", () => handleOctAction(-1));
  button(L.oct[1], "OCT+", "", () => handleOctAction(1));
  const [gx, gy, gw, gh, dx, dy] = L.grid;
  for (let i = 0; i < 6; i++) {
    button([gx + i * dx, gy, gw, gh], ROW1[i], "", (e, held) => topButton(ROW1[i], e, held));
    button([gx + i * dx, gy + dy, gw, gh], ROW2[i], ROW2[i] === "PLAY" ? "STOP" : "", () => lowerButton(ROW2[i]));
  }
  const [x0, y0, w, h] = L.keybed;
  el("rect", { x: x0, y: y0, width: w, height: h, rx: 18, fill: "var(--tray)" });
  const pitch = (w - 24) / 16, kw = pitch * 0.78, kh = h * 0.425, sw = Math.max(3, kw * 0.14);
  const key = (x, y, k, fn, cls, keyLabel, up) => {
    keyLabel ||= cls === "step" ? `Step ${WHITE.indexOf(k) + 1}` : `Control ${BLACK.indexOf(k) + 1}`;
    const g = el("g", { class: "keyg", role: "button", tabindex: 0, "aria-label": keyLabel, "aria-pressed": "false" }), top = y - kh / 2;
    const state = { g, cls, pressed: false };
    el("rect", { x: x - kw / 2, y: top, width: kw, height: kh, rx: kw / 2, class: "face key" }, g);
    el("rect", { x: x - sw / 2, y: top + kw * 0.4, width: sw, height: kh - kw * 0.8, rx: sw / 2, class: "slit" }, g);
    el("rect", { x: x - pitch / 2, y: y - h * 0.24, width: pitch, height: h * 0.48, fill: "transparent" }, g);
    const release = () => { if (state.pressed) { state.pressed = false; up?.(); redraw(); } };
    g.addEventListener("pointerdown", (e) => { e.preventDefault(); state.pressed = true; g.classList.add("held"); g.setPointerCapture?.(e.pointerId); fn(e); });
    g.addEventListener("keydown", (e) => { if ((e.key === "Enter" || e.key === " ") && !e.repeat) { e.preventDefault(); state.pressed = true; redraw(); fn(e); } });
    g.addEventListener("keyup", release);
    for (const ev of ["pointerup", "pointerleave", "pointercancel", "lostpointercapture"]) g.addEventListener(ev, release);
    keys[k] = state;
  };
  WHITE.forEach((k, i) => key(x0 + 12 + (i + 0.5) * pitch, y0 + h * 0.75, k, (e) => pressStep(i, e), "step", undefined, () => releaseStep(i)));
  BLACK_AFTER.forEach((a, j) => {
    const name = j < 8 ? `Track ${j + 1}` : ["Accent modifier", "Fill retrigger modifier", "Next step page"][j - 8];
    key(x0 + 12 + (a + 1) * pitch, y0 + h * 0.25, BLACK[j], (e) => blackKey(j, e), "black", name);
  });
  canvas.addEventListener("pointerdown", (e) => {
    const r = canvas.getBoundingClientRect(), y = (e.clientY - r.top) * 240 / r.height;
    if (S && y >= 44 && y < 180) { lane = Math.min(7, Math.floor((y - 44) / 17)); redraw(); }
  });
  redraw();
}
function bindKnob(o, i) {
  o.g.addEventListener("pointerdown", (e) => { knobDrag.set(i, { y: e.clientY, remainder: 0 }); o.g.setPointerCapture(e.pointerId); e.preventDefault(); });
  o.g.addEventListener("pointermove", (e) => {
    const drag = knobDrag.get(i);
    if (!drag) return;
    drag.remainder += drag.y - e.clientY; drag.y = e.clientY;
    const pixelsPerStep = i < 4 ? (e.shiftKey ? 24 : 12) : (e.shiftKey ? 6 : 3);
    const steps = Math.trunc(drag.remainder / pixelsPerStep);
    if (!steps) return;
    drag.remainder -= steps * pixelsPerStep;
    turnKnob(i, steps * (i < 4 ? 8 : 3), e.shiftKey);
  });
  o.g.addEventListener("pointerup", () => knobDrag.delete(i));
  o.g.addEventListener("pointercancel", () => knobDrag.delete(i));
  o.g.addEventListener("wheel", (e) => { e.preventDefault(); turnKnob(i, e.deltaY < 0 ? 8 : -8); }, { passive: false });
}
function knobValue(index) {
  if (saveFlow && index === (saveFlow.kind === "project" ? 3 : 2)) return saveFlow.slots.indexOf(saveFlow.slot) / Math.max(1, saveFlow.slots.length - 1);
  if (loadFlow && index === 2) return PROJECT_SLOTS.indexOf(loadFlow.slot) / Math.max(1, PROJECT_SLOTS.length - 1);
  if (screen === "device" && index === 1) return selectedDeviceSetting / Math.max(1, DEVICE_SETTINGS.length - 1);
  if (screen === "device" && index === 3) {
    const item = DEVICE_SETTINGS[selectedDeviceSetting], values = item?.values || [];
    return Math.max(0, values.indexOf(deviceSettings[item?.key])) / Math.max(1, values.length - 1);
  }
  if (screen === "mixer" && index === 3) return trackVolumes[lane];
  if (index === 0) return volume;
  if (index === 1) return lane / 7;
  if (index === 2) return PROJECT_SLOTS.indexOf(projectLoadSlot) / Math.max(1, PROJECT_SLOTS.length - 1);
  if (index === 3) return editPage / 4;
  const page = screen === "home" ? "home" : screen;
  if (page === "global") return [tempo / 240, (swing - 50) / 50, clip, (clampPan(pans[lane]) + 1) / 2][index - 4];
  if (screen === "device") return 0;
  const p = PAGE_PARAMS[page] || PAGE_PARAMS.home, pi = p[index - 4];
  return parameterValue(lane, pi);
}
function parameterValue(d, pi) {
  const patch = playing ? displayPatches[d] : null;
  return patch?.[pi] ?? P[d]?.[pi] ?? 0;
}
function drawKnob(o, i) {
  const v = Math.max(0, Math.min(1, knobValue(i)));
  o.val = v;
  o.g.setAttribute("aria-valuenow", String(Math.round(v * 100)));
  o.g.setAttribute("aria-valuetext", `${o.name}: ${Math.round(v * 100)} percent`);
  if (o.ind) o.ind.setAttribute("transform", `rotate(${-135 + 270 * v} ${o.x} ${o.y})`);
}
function turnKnob(index, dy, fine = false) {
  if (saveFlow) {
    const slotKnob = saveFlow.kind === "project" ? 3 : 2;
    if (index === slotKnob) { if (saveFlow.phase === "confirm") saveFlow.phase = "pick"; changeSaveSlot(dy); }
    else if (index !== slotKnob) message(`Turn ${slotKnob === 3 ? "ALGORITHM" : "PRESETS"} to choose a slot.`);
    redraw(); return;
  }
  if (loadFlow) {
    if (index === 2) { if (loadFlow.phase === "confirm") loadFlow.phase = "pick"; changeLoadSlot(dy); }
    else if (index !== 2) message("Turn PRESETS to choose a project.");
    redraw(); return;
  }
  if (screen === "device") {
    if (index === 1) {
      const amount = Math.max(1, Math.round(Math.abs(dy) / 8));
      selectedDeviceSetting = ((selectedDeviceSetting + Math.sign(dy) * amount) % DEVICE_SETTINGS.length + DEVICE_SETTINGS.length) % DEVICE_SETTINGS.length;
    } else if (index === 3) changeDeviceSetting(dy);
    else if (index === 2) startProjectLoadFlow(dy);
    redraw(); return;
  }
  if (screen === "mixer") {
    if (index === 1) lane = Math.max(0, Math.min(7, lane + Math.sign(dy) * Math.max(1, Math.round(Math.abs(dy) / 8))));
    else if (index === 3) {
      trackVolumes[lane] = clamp01(trackVolumes[lane] + dy / (fine ? 800 : 400));
      const voice = voices[lane];
      if (voice && ctx) voice.g.gain.setTargetAtTime(0.82 * trackVolumes[lane], ctx.currentTime, 0.01);
      saveLocal();
    }
    redraw(); return;
  }
  if (index === 2) { startProjectLoadFlow(dy); redraw(); return; }
  if (index === 0) { volume = clamp01(volume + dy / (fine ? 320 : 160)); setMasterGain(); }
  else if (index === 1) lane = Math.max(0, Math.min(7, lane + Math.sign(dy) * Math.max(1, Math.round(Math.abs(dy) / 8))));
  else if (index === 3) { editPage = Math.max(0, Math.min(4, editPage + Math.sign(dy) * Math.max(1, Math.round(Math.abs(dy) / 8)))); if (screen === "edit") screen = ["edit", "lfo", "scl", "env", "fx"][editPage]; }
  else if (screen === "global") {
    if (index === 4) tempo = Math.max(40, Math.min(240, tempo + dy * (fine ? 0.35 : 0.7)));
    if (index === 5) swing = Math.max(50, Math.min(100, swing + dy * (fine ? 0.1 : 0.2)));
    if (index === 6) { clip = clip ? 0 : 1; updateShaper(); }
    if (index === 7) { pans[lane] = clampPan(pans[lane] + dy / (fine ? 320 : 160)); if (S) syncPatch(lane); updateVoicePan(lane); }
    focusHomeControl(index - 4);
    setMasterGain();
  } else {
    const page = PAGE_PARAMS[screen] ? screen : "home", p = PAGE_PARAMS[page], pi = p[index - 4];
    if (P[lane] && pi !== undefined) {
      const step = MODES[pi] ? 0.5 : 1 / (fine ? 254 : 127);
      const direction = Math.sign(dy);
      const amount = Math.max(1, Math.round(Math.abs(dy) / 6));
      const value = P[lane][pi];
      if (MODES[pi]) {
        const choices = MODES[pi], at = choices.reduce((best, v, n) => Math.abs(v - value) < Math.abs(choices[best] - value) ? n : best, 0);
        P[lane][pi] = choices[Math.max(0, Math.min(choices.length - 1, at + direction * amount))];
      } else P[lane][pi] = clamp01(value + direction * amount * step);
      const recordedStep = recording ? recordAutomation(lane, pi, P[lane][pi]) : -1;
      if (playing) {
        if (!displayPatches[lane]) prepareDisplayPattern(displayPattern || pat);
        displayPatches[lane][pi] = P[lane][pi];
      }
      focusParameter(index - 4);
      syncPatch(lane);
      renderLane(lane);
      if (playing) {
        playbackPatches[lane] ||= P[lane].slice();
        playbackPatches[lane][pi] = P[lane][pi];
        playbackBuffers[lane] = playbackPatches[lane].every((v, n) => v === P[lane][n])
          ? bufs[lane] : makeAudioBuffer(lane, playbackPatches[lane], false) || bufs[lane];
      }
      if (recordedStep >= 0) message(`REC automation · TRACK ${lane + 1} · step ${recordedStep + 1} · ${PARAM_LABELS[pi]} ${paramDisplay(pi, P[lane][pi])}`);
      else if (recording) message("REC armed · select a step or start playback before turning a sound-page knob.");
    }
  }
  saveLocal(); redraw();
}
function topButton(name, e, held = false) {
  if (name === "FX") screen = "fx";
  else if (name === "SEL") screen = "scl";
  else if (name === "ENV") screen = "env";
  else if (name === "LFO") screen = "lfo";
  else if (name === "EDIT") {
    const pages = ["edit", "lfo", "scl", "env", "fx"], at = pages.indexOf(screen);
    editPage = at < 0 ? 0 : (at + 1) % pages.length; screen = pages[editPage];
  }
  else if (name === "GLO") { screen = held || e?.shiftKey ? "mixer" : "device"; message(screen === "mixer" ? "MASTER MIXER · SELECT chooses track, ALGORITHM changes its level." : "GLOBAL SETTINGS · SELECT chooses an item, ALGORITHM changes its value."); }
  redraw();
}
function lowerButton(name) {
  if (name === "HOME") screen = "global";
  else if (name === "SAVE") handleSaveButton();
  else if (name === "ARP") { screen = "mix"; message("Marked per-trig FILL retriggers are always active; ARP does not gate them."); }
  else if (name === "SEQ") { screen = "home"; message("Sequence grid."); }
  else if (name === "PLAY") playing ? stop() : play();
  else if (name === "REC") {
    recording = !recording;
    if (recording && S) {
      const base = P.map((patch) => patch.slice());
      const key = playing && displayPattern ? displayPattern : pat;
      ensurePattern(key).automationBase = base.map((patch) => patch.slice());
      if (playing) {
        ensurePattern(pat).automationBase = base.map((patch) => patch.slice());
        preparePlaybackPattern(pat); prepareDisplayPattern(key);
      }
      saveLocal();
    }
    message(recording ? "REC armed. Turn a sound-page knob during playback, or select a step while stopped, to record automation." : "REC disarmed.");
  }
  redraw();
}
function copyData(value) { return JSON.parse(JSON.stringify(value)); }
function handleSaveButton() {
  if (!S) { message("Load a preset before saving a pattern."); return; }
  if (settingsDirty) { commitDeviceSettings(); return; }
  startSaveFlow("pattern");
}
function startSaveFlow(kind) {
  if (kind === "project" && !S) { message("Load a preset before saving a project."); return; }
  const slots = kind === "pattern" ? SAVE_PATTERN_SLOTS : PROJECT_SLOTS;
  quickPatternArm = false;
  saveFlow = { kind, phase: "pick", slots, slot: slots[0], touched: false };
  clearTimeout(saveFlowTimer); clearTimeout(loadFlowTimer); loadFlow = null;
  if (kind === "project") {
    saveFlow.touched = true;
    saveFlowTimer = setTimeout(() => { if (saveFlow?.touched) { saveFlow.phase = "confirm"; redraw(); } }, 1000);
  }
  redraw();
}
function changeSaveSlot(dy) {
  if (!saveFlow || !dy) return;
  const current = saveFlow.slots.indexOf(saveFlow.slot), step = Math.max(1, Math.round(Math.abs(dy) / 8));
  const next = ((current + Math.sign(dy) * step) % saveFlow.slots.length + saveFlow.slots.length) % saveFlow.slots.length;
  saveFlow.slot = saveFlow.slots[next]; saveFlow.touched = true; saveFlow.phase = "pick";
  clearTimeout(saveFlowTimer);
  saveFlowTimer = setTimeout(() => { if (saveFlow?.touched) { saveFlow.phase = "confirm"; redraw(); } }, saveFlow.kind === "project" ? 1000 : 700);
}
function startProjectLoadFlow(dy) {
  if (playing) { message("Stop the sequencer before loading a project."); return; }
  if (!loadFlow) {
    quickPatternArm = false;
    clearTimeout(saveFlowTimer); saveFlow = null;
    loadFlow = { phase: "pick", slot: projectLoadSlot };
    clearTimeout(loadFlowTimer);
    loadFlowTimer = setTimeout(() => { if (loadFlow) { loadFlow.phase = "confirm"; redraw(); } }, 1000);
    redraw(); return;
  }
  changeLoadSlot(dy);
}
function changeLoadSlot(dy) {
  if (!loadFlow || !dy) return;
  const current = PROJECT_SLOTS.indexOf(loadFlow.slot), step = Math.max(1, Math.round(Math.abs(dy) / 8));
  const next = ((current + Math.sign(dy) * step) % PROJECT_SLOTS.length + PROJECT_SLOTS.length) % PROJECT_SLOTS.length;
  projectLoadSlot = PROJECT_SLOTS[next]; loadFlow.slot = projectLoadSlot; loadFlow.phase = "pick";
  clearTimeout(loadFlowTimer);
  loadFlowTimer = setTimeout(() => { if (loadFlow) { loadFlow.phase = "confirm"; redraw(); } }, 1000);
}
function handleOctAction(direction) {
  if (quickPatternArm && !saveFlow && !loadFlow) {
    quickPatternArm = false;
    if (direction < 0) deleteSelectedPattern(); else transpose(direction);
    return;
  }
  if (loadFlow) {
    if (direction < 0) {
      clearTimeout(loadFlowTimer); loadFlow = null; message("Project load cancelled.");
      redraw(); return;
    }
    if (loadFlow.phase !== "confirm") { message("Stop turning PRESETS and wait to confirm the project slot."); return; }
    if (playing) { message("Stop the sequencer before loading a project."); return; }
    const slot = loadFlow.slot, key = `fm1-tonic-project-slot-${slot}`;
    try {
      const data = localStorage.getItem(key);
      if (!data) { loadFlow.phase = "pick"; message(`Project slot ${slot} is empty.`); redraw(); return; }
      const project = JSON.parse(data); clearTimeout(loadFlowTimer); loadFlow = null;
      loadProjectBackup(project, `project ${slot}`); message(`Project ${slot} loaded.`);
    } catch (err) { loadFlow.phase = "pick"; message(`Could not load project ${slot}: ${err.message}`); redraw(); }
    return;
  }
  if (!saveFlow) { transpose(direction); return; }
  if (direction < 0) {
    if (saveFlow.kind === "project" && saveFlow.phase === "confirm") {
      clearTimeout(saveFlowTimer); saveFlow.phase = "pick"; saveFlow.touched = false;
      redraw(); message("Turn ALGORITHM to choose another project slot, or OCT- again to cancel."); return;
    }
    clearTimeout(saveFlowTimer); saveFlow = null; redraw(); message("Save cancelled."); return;
  }
  if (saveFlow.phase !== "confirm") { message(`Turn ${saveFlow.kind === "project" ? "ALGORITHM" : "PRESETS"} to choose a slot, then wait to confirm.`); return; }
  const flow = saveFlow;
  clearTimeout(saveFlowTimer); saveFlow = null; redraw();
  if (flow.kind === "project") {
    const snapshot = projectSnapshot();
    message(`Saving project ${flow.slot}…`);
    blinkAlgorithmKnob(() => {
      try {
        localStorage.setItem(`fm1-tonic-project-slot-${flow.slot}`, JSON.stringify(snapshot));
        message(`Project saved to ${flow.slot} slot.`);
      } catch (err) { message(`Could not save slot: ${err.message}`); }
    });
    return;
  }
  try {
    const target = flow.slot.toLowerCase();
    S.pats[target] = copyData(ensurePattern(pat));
    pat = target; bank = 0;
    message(`Pattern saved to ${flow.slot} slot.`);
    saveLocal();
  } catch (err) { message(`Could not save slot: ${err.message}`); }
  redraw();
}
function blinkAlgorithmKnob(onDone) {
  const knob = knobs[3]?.g;
  if (!knob) { onDone(); return; }
  knob.classList.add("saveblink");
  setTimeout(() => { knob.classList.remove("saveblink"); onDone(); }, 600);
}
function projectSnapshot() {
  return {
    format: "fm1-tonic-project-v1", preset: serializePreset(), patterns: copyData(S.pats),
    automation: automationSnapshot(), automationBase: automationBaseSnapshot(),
    page: screen, lane, pattern: pat, volume, clip, swing, trackVolumes: trackVolumes.slice(),
  };
}
function changeDeviceSetting(delta) {
  if (!delta) return;
  const item = DEVICE_SETTINGS[selectedDeviceSetting];
  if (!item) return;
  if (item.action) { startSaveFlow("project"); return; }
  const values = item.values, current = Math.max(0, values.indexOf(deviceSettings[item.key]));
  const amount = Math.max(1, Math.round(Math.abs(delta) / 8));
  const next = ((current + Math.sign(delta) * amount) % values.length + values.length) % values.length;
  deviceSettings[item.key] = values[next];
  settingsDirty = JSON.stringify(deviceSettings) !== JSON.stringify(savedDeviceSettings);
  if (item.key === "output") setOutputGain();
  message(`${item.label}: ${deviceSettings[item.key]}${settingsDirty ? " · press SAVE to keep" : " · saved value"}`);
}
function restoreDeviceSettings() {
  try {
    const saved = JSON.parse(localStorage.getItem("fm1-tonic-device-settings") || "null");
    if (saved && typeof saved === "object")
      for (const item of DEVICE_SETTINGS) if (item.values?.includes(saved[item.key])) deviceSettings[item.key] = saved[item.key];
  } catch { /* use defaults when storage is unavailable */ }
  savedDeviceSettings = { ...deviceSettings }; settingsDirty = false;
}
function setMasterGain() {
  if (master) master.gain.value = volume * 0.5;
}
function setOutputGain() {
  if (outputGainNode) outputGainNode.gain.value = deviceSettings.output === "LOUD" ? Math.pow(10, 6 / 20) : 1;
}
function commitDeviceSettings() {
  try {
    localStorage.setItem("fm1-tonic-device-settings", JSON.stringify(deviceSettings));
    savedDeviceSettings = { ...deviceSettings }; settingsDirty = false;
    setOutputGain();
    redraw(); message("Global settings saved. They will be restored next time the preview opens.");
  } catch (err) { message(`Settings could not be saved: ${err.message}`); }
}
function selectPatternSlot(index) {
  if (!S) return;
  const key = PATTERN_SLOTS[index];
  if (!key) return;
  ensurePattern(key); pat = key; bank = 0; selectedStep = -1; screen = "home";
  saveLocal(); redraw(); message(`Pattern ${key.toUpperCase()} selected.`);
}
function deleteSelectedPattern() {
  if (!S) return;
  if (playing) stop();
  const removed = pat;
  if (patternKeys().length <= 1) {
    const p = ensurePattern(removed);
    p.lanes = Array.from({ length: 8 }, () => ({ Triggers: "-".repeat(p.len), Accents: "-".repeat(p.len), Fills: "-".repeat(p.len) }));
    delete p.automation; delete p.automationBase;
  } else delete S.pats[removed];
  pat = patternKeys()[0] || "a"; ensurePattern(pat); bank = 0; selectedStep = -1;
  saveLocal(); redraw(); message(`Pattern ${removed.toUpperCase()} deleted.`);
}
function transpose(dir) {
  if (!P[lane]) return;
  const delta = Math.log(2) / Math.log(1000) * dir;
  P[lane][1] = clamp01(P[lane][1] + delta);
  syncPatch(lane); renderLane(lane); redraw();
}
function clamp01(v) { return Math.max(0, Math.min(1, v)); }
function clampPan(v) { return Math.max(-1, Math.min(1, Number(v) || 0)); }
function panLabel(v) { return v < -0.08 ? "LEFT" : v > 0.08 ? "RIGHT" : "CENTRE"; }
function patternKeys() { return S ? Object.keys(S.pats).sort() : []; }
function ensurePattern(key) {
  if (!S.pats[key]) S.pats[key] = { len: 16, chained: false, lanes: [] };
  const p = S.pats[key]; p.len = Math.max(1, Math.min(64, +p.len || 16)); p.lanes ||= [];
  for (let d = 0; d < 8; d++) p.lanes[d] ||= { Triggers: "-".repeat(p.len), Accents: "-".repeat(p.len), Fills: "-".repeat(p.len) };
  return p;
}
function ensureAutomation(p) {
  if (!Array.isArray(p.automation)) p.automation = [];
  for (let d = 0; d < 8; d++) if (!p.automation[d] || typeof p.automation[d] !== "object") p.automation[d] = {};
  return p.automation;
}
function recordAutomation(d, pi, value) {
  const key = playing && displayPattern ? displayPattern : pat;
  const p = ensurePattern(key);
  const runningStep = cur >= 0 ? cur : q.length ? q[0][1] : stp > 0 ? (stp - 1) % p.len : -1;
  const step = playing ? runningStep % p.len : selectedPattern === key && selectedLane === d ? selectedStep : -1;
  if (step < 0 || step >= p.len) return -1;
  const values = ensureAutomation(p)[d][step] ||= {};
  values[pi] = clamp01(value);
  return step;
}
function automationSnapshot() {
  const out = {};
  for (const key of patternKeys()) {
    const lanes = ensureAutomation(ensurePattern(key));
    out[key] = lanes.map((laneData) => Object.fromEntries(Object.entries(laneData).map(([step, values]) => [step, { ...values }])));
  }
  return out;
}
function automationBaseSnapshot() {
  const out = {};
  for (const key of patternKeys()) {
    const base = S.pats[key]?.automationBase;
    if (Array.isArray(base)) out[key] = base.map((patch) => Array.isArray(patch) ? patch.slice() : null);
  }
  return out;
}
function restoreAutomation(snapshot, bases = {}) {
  if (!S) return;
  for (const [key, sourceLanes] of Object.entries(snapshot && typeof snapshot === "object" ? snapshot : {})) {
    if (!S.pats[key]) continue;
    const p = ensurePattern(key);
    p.automation = Array.from({ length: 8 }, (_, d) => {
      const clean = {}, laneSource = sourceLanes?.[d];
      if (!laneSource || typeof laneSource !== "object") return clean;
      for (const [stepText, sourceValues] of Object.entries(laneSource)) {
        const step = Number(stepText);
        if (!Number.isInteger(step) || step < 0 || step >= p.len || !sourceValues || typeof sourceValues !== "object") continue;
        const values = {};
        for (const [indexText, value] of Object.entries(sourceValues)) {
          const index = Number(indexText), number = Number(value);
          if (Number.isInteger(index) && index >= 0 && index < PARAM_NAMES.length && Number.isFinite(number)) values[index] = clamp01(number);
        }
        if (Object.keys(values).length) clean[step] = values;
      }
      return clean;
    });
  }
  if (bases && typeof bases === "object") {
    for (const [key, patches] of Object.entries(bases)) {
      if (!S.pats[key] || !Array.isArray(patches)) continue;
      S.pats[key].automationBase = Array.from({ length: 8 }, (_, d) =>
        Array.isArray(patches[d]) && patches[d].length === PARAM_NAMES.length
          ? patches[d].map((v) => clamp01(Number(v))) : null);
      S.pats[key].automationBase = S.pats[key].automationBase.map((patch, d) => patch || P[d]?.slice() || []);
    }
  }
}
function laneData() { return ensurePattern(pat).lanes[lane]; }
function pageGo(direction) {
  if (!S) return;
  const p = ensurePattern(pat), pages = Math.ceil(p.len / 16);
  if (pages < 2) return;
  bank = (bank + pages + direction) % pages;
  redraw(); message(`${pat.toUpperCase()} · page ${bank + 1}/${pages}.`);
}
function blackKey(index, e) {
  if (!S || saveFlow || loadFlow) return;
  if (index < 8) { lane = index; selectedStep = -1; selectedLane = lane; selectedPattern = pat; audition(index); return; }
  if (index === 8) { toggleSelectedModifier("Accents"); return; }
  if (index === 9) { toggleSelectedModifier("Fills"); return; }
  if (e?.shiftKey) { quickPatternArm = true; message("PAD 11 held · press white 1–16 to select a pattern, or OCT- to delete it."); return; }
  pageGo(e?.shiftKey ? -1 : 1);
}
function selectedModifierStep() {
  if (selectedPattern === pat && selectedLane === lane && selectedStep >= 0) return selectedStep;
  if (playing && cur >= 0) return cur % ensurePattern(pat).len;
  return -1;
}
function toggleSelectedModifier(field) {
  if (!S) return;
  const name = field === "Accents" ? "accent" : "fill retrigger";
  if (heldTrigs.size) {
    /* New gesture: a trig key is held, so the modifier applies to the held trig(s). */
    const hs = [...heldTrigs.values()], first = hs[0];
    const enabled = laneOf(first)?.[field]?.[first.step] !== "#";
    for (const h of hs) {
      const l = laneOf(h); if (!l) continue;
      setFlag(h, field, enabled);
      if (enabled) setFlag(h, "Triggers", true);
      h.used = true;
    }
    selectedStep = first.step; selectedLane = first.lane; selectedPattern = first.pat;
    message(`${first.pat.toUpperCase()} · TRACK ${first.lane + 1} · step ${first.step + 1} ${name} ${enabled ? "on" : "off"}.`);
    saveLocal(); redraw(); return;
  }
  const p = ensurePattern(pat), step = selectedModifierStep();
  if (step < 0 || step >= p.len) { message(`Hold a TRACK ${lane + 1} trig, then press ${field === "Accents" ? "pad 9" : "pad 10"}.`); return; }
  const l = p.lanes[lane];
  if (l.Triggers?.[step] !== "#") { message(`Add a TRACK ${lane + 1} trig on step ${step + 1} first.`); return; }
  const enabled = l[field]?.[step] !== "#";
  updateLaneString(l, field, step, enabled);
  if (enabled && field === "Accents") updateLaneString(l, "Triggers", step, true);
  selectedStep = step; selectedLane = lane; selectedPattern = pat;
  message(`${pat.toUpperCase()} · TRACK ${lane + 1} · step ${step + 1} ${name} ${enabled ? "on" : "off"}.`);
  saveLocal(); redraw();
}
/* Held-trig gesture: keep a trig key pressed (it stays in place) and press pad 9 (accent) and/or pad 10 (fill) to add or remove them.
   Tap an empty step = trig on. Tap an existing trig and release without a modifier = trig off (clears trig, accent and fill). */
const heldTrigs = new Map();
const laneOf = (h) => ensurePattern(h.pat).lanes[h.lane];
function setFlag(h, field, value) {
  const l = laneOf(h), len = ensurePattern(h.pat).len, old = (l[field] || "").padEnd(len, "-").slice(0, len);
  l[field] = old.slice(0, h.step) + (value ? "#" : "-") + old.slice(h.step + 1);
}
function pressStep(i, e) {
  if (!S || saveFlow || loadFlow) return;
  if (quickPatternArm || e?.shiftKey || e?.altKey) { toggleStep(i, e); return; }
  const p = ensurePattern(pat), step = bank * 16 + i;
  if (step >= p.len) return;
  const h = { step, lane, pat, hadTrig: p.lanes[lane].Triggers?.[step] === "#", used: false };
  heldTrigs.set(i, h);
  if (!h.hadTrig) { setFlag(h, "Triggers", true); h.used = true; message(`${pat.toUpperCase()} · TRACK ${lane + 1} · step ${step + 1} on. Hold it and press ACC / FILL.`); }
  else message(`${pat.toUpperCase()} · TRACK ${lane + 1} · step ${step + 1}: hold + pad 9 accent, pad 10 fill; release alone = off.`);
  selectedStep = step; selectedLane = lane; selectedPattern = pat;
  saveLocal(); redraw();
}
function releaseStep(i) {
  const h = heldTrigs.get(i); if (!h) return;
  heldTrigs.delete(i);
  if (h.hadTrig && !h.used && laneOf(h)) {
    for (const field of ["Triggers", "Accents", "Fills"]) setFlag(h, field, false);
    message(`${h.pat.toUpperCase()} · TRACK ${h.lane + 1} · step ${h.step + 1} off.`);
    saveLocal();
  }
}
function updateLaneString(l, field, i, value) {
  const p = ensurePattern(pat), old = (l[field] || "").padEnd(p.len, "-").slice(0, p.len);
  l[field] = old.slice(0, i) + (value ? "#" : "-") + old.slice(i + 1);
}
function toggleStep(i, e) {
  if (!S || saveFlow || loadFlow) return;
  if (quickPatternArm) { quickPatternArm = false; selectPatternSlot(i); return; }
  if (e?.shiftKey) { selectPatternSlot(i); return; }
  const p = ensurePattern(pat), step = bank * 16 + i;
  if (step >= p.len) return;
  const l = laneData(), hasAny = ["Triggers", "Accents", "Fills"].some((field) => l[field]?.[step] === "#");
  if (e?.altKey) {
    const enabled = l.Fills?.[step] !== "#";
    updateLaneString(l, "Fills", step, enabled);
    if (enabled) updateLaneString(l, "Triggers", step, true);
    message(`${pat.toUpperCase()} · step ${step + 1} fill retrigger ${enabled ? "on" : "off"}.`);
  } else {
    for (const field of ["Triggers", "Accents", "Fills"]) updateLaneString(l, field, step, false);
    if (!hasAny) updateLaneString(l, "Triggers", step, true);
    message(`${pat.toUpperCase()} · TRACK ${lane + 1} · step ${step + 1} ${hasAny ? "off" : "on"}.`);
  }
  selectedStep = step; selectedLane = lane; selectedPattern = pat;
  saveLocal(); redraw();
}
function focusParameter(slot) {
  focusedHomeSlot = -1;
  focusedParamSlot = slot;
  clearTimeout(focusTimer);
  focusTimer = setTimeout(() => { focusedParamSlot = -1; redraw(); }, 3500);
}
function focusHomeControl(slot) {
  focusedParamSlot = -1; focusedHomeSlot = slot;
  clearTimeout(focusTimer);
  focusTimer = setTimeout(() => { focusedHomeSlot = -1; redraw(); }, 3500);
}

/* LCD and physical panel LEDs */
function drawScreen() {
  c.fillStyle = LCD.bg; c.fillRect(0, 0, 240, 240); c.textBaseline = "top";
  const F = (px) => { c.font = `${px}px ${DOT}`; };
  const T = (s, x, y, color = LCD.primary, align = "left") => { c.fillStyle = color; c.textAlign = align; c.fillText(String(s), x, y); };
  if (saveFlow) { drawSaveFlow(F, T); return; }
  if (loadFlow) { drawLoadFlow(F, T); return; }
  if (!S) { F(16); T("FM1 TONIC", 120, 100, LCD.primary, "center"); T("no preset", 120, 124, LCD.muted, "center"); return; }
  const p = ensurePattern(pat);
  F(15); T("FM1 TONIC", 4, 2); T(`PAT ${pat.toUpperCase()}`, 236, 2, LCD.highlight, "right");
  F(12); T(`${Math.round(tempo)} BPM   SW ${swing.toFixed(1)}%`, 4, 20, LCD.secondary);
  if (screen === "home") {
    const cw = 12.35;
    const first = bank * 16;
    for (let d = 0; d < 8; d++) {
      const y = 45 + d * 17, l = p.lanes[d] || {};
      if (d === lane) { c.fillStyle = LCD.row; c.fillRect(0, y - 1, 240, 16); }
      F(12); T(`${d + 1}`, 8, y, d === lane ? LCD.highlight : LCD.secondary);
      for (let s = first; s < Math.min(p.len, first + 16); s++) {
        const x = 36 + (s - first) * cw, hit = l.Triggers?.[s] === "#", accent = l.Accents?.[s] === "#", fill = l.Fills?.[s] === "#";
        c.fillStyle = accent && fill ? LCD.both : fill ? LCD.fill : accent ? LCD.trigAccent : hit ? LCD.hit : LCD.track;
        c.fillRect(x, y + 1, cw - 2, 12);
        if (p.automation?.[d]?.[s] && Object.keys(p.automation[d][s]).length) { c.fillStyle = LCD.highlight; c.fillRect(x, y + 1, cw - 2, 2); }
        if (s === cur) { c.strokeStyle = LCD.cursor; c.strokeRect(x - 0.5, y + 0.5, cw - 1, 13); }
      }
    }
    F(12); T(`PG ${bank + 1}/${Math.ceil(p.len / 16)} · TRACK ${lane + 1} · ${playing ? "PLAYING" : "STOPPED"}`, 4, 185, playing ? LCD.cursor : LCD.secondary);
    T(`TRACK ${lane + 1} PAN · ${panLabel(pans[lane])}`, 4, 205, LCD.secondary);
    if (recording) T("REC ARMED", 4, 224, LCD.alert);
    else { T("HOLD TRIG +", 4, 224, LCD.muted); T("ACC", 88, 224, LCD.trigAccent); T("FILL", 118, 224, LCD.fill); T("BOTH", 152, 224, LCD.both); }
  } else if (screen === "global") {
    F(14); T("HOME", 4, 43, LCD.highlight);
    drawHomeKnobs(F, T);
  } else if (screen === "device") {
    drawDeviceSettings(F, T);
  } else if (screen === "mixer") {
    drawMasterMixer(F, T);
  } else {
    const params = PAGE_PARAMS[screen] || PAGE_PARAMS.home;
    F(13); T(`TRACK ${lane + 1} · ${screen.toUpperCase()}`, 4, 43, LCD.highlight);
    drawParameterPage(params);
  }
}
function drawSaveFlow(F, T) {
  c.fillStyle = LCD.bg; c.fillRect(0, 0, 240, 240);
  F(13); T(saveFlow.kind === "pattern" ? "QUICK SAVE PATTERN" : "SAVE PROJECT", 120, 28, LCD.highlight, "center");
  if (saveFlow.phase === "pick") {
    F(12); T(saveFlow.kind === "pattern" ? "TURN PRESETS KNOB" : `SAVE TO ${saveFlow.slot}`, 120, 69, LCD.secondary, "center");
    F(38); T(saveFlow.kind === "pattern" ? saveFlow.slot : "", 120, 99, LCD.primary, "center");
    F(11); T(saveFlow.kind === "pattern" ? "PATTERN SLOT · A–L" : "TURN ALGORITHM · PROJECT A–P", 120, 151, LCD.muted, "center");
    F(10); T("OCT- CANCEL", 120, 207, LCD.secondary, "center");
  } else {
    F(13); T(`SAVE ON ${saveFlow.slot} SLOT?`, 120, 83, LCD.primary, "center");
    F(12); T("OCT+  [ YES ]", 120, 132, LCD.highlight, "center");
    T("OCT-  [ NO ]", 120, 159, LCD.secondary, "center");
  }
}
function drawLoadFlow(F, T) {
  c.fillStyle = LCD.bg; c.fillRect(0, 0, 240, 240);
  F(13); T("LOAD PROJECT", 120, 28, LCD.highlight, "center");
  if (loadFlow.phase === "pick") {
    F(12); T("TURN PRESETS KNOB", 120, 69, LCD.secondary, "center");
    F(38); T(loadFlow.slot, 120, 99, LCD.primary, "center");
    F(11); T("PROJECT SLOT · A–P", 120, 151, LCD.muted, "center");
    F(10); T(playing ? "STOP SEQUENCER FIRST" : "WAIT 1 SEC TO CONFIRM", 120, 207, LCD.secondary, "center");
  } else {
    F(14); T(`LOAD PROJECT ${loadFlow.slot}?`, 120, 83, LCD.primary, "center");
    F(12); T("OCT+  [ YES ]", 120, 132, LCD.highlight, "center");
    T("OCT-  [ NO ]", 120, 159, LCD.secondary, "center");
  }
}
function drawDeviceSettings(F, T) {
  F(14); T("GLOBAL", 4, 43, LCD.highlight);
  DEVICE_SETTINGS.forEach((item, i) => {
    const y = 61 + i * 22;
    if (i === selectedDeviceSetting) { c.fillStyle = LCD.row; c.fillRect(0, y - 2, 240, 20); }
    F(10); T(item.label, 5, y, i === selectedDeviceSetting ? LCD.highlight : LCD.secondary);
    const value = item.action ? "→" : deviceSettings[item.key];
    T(value, 235, y, i === selectedDeviceSetting ? LCD.primary : LCD.secondary, "right");
  });
  F(9); T(settingsDirty ? "SAVE TO KEEP CHANGES" : "SELECT SCROLL · ALGO CHANGE", 120, 224, settingsDirty ? LCD.alert : LCD.muted, "center");
}
function drawMasterMixer(F, T) {
  F(14); T("MASTER MIXER", 4, 43, LCD.highlight);
  trackVolumes.forEach((value, i) => {
    const y = 62 + i * 20;
    if (i === lane) { c.fillStyle = LCD.row; c.fillRect(0, y - 2, 240, 18); }
    F(11); T(String(i + 1), 7, y, i === lane ? LCD.highlight : LCD.secondary);
    c.fillStyle = LCD.track; c.fillRect(34, y + 4, 158, 6);
    c.fillStyle = i === lane ? LCD.highlight : LCD.accent; c.fillRect(34, y + 4, 158 * value, 6);
    F(9); T(`${Math.round(value * 100)}%`, 235, y, LCD.secondary, "right");
  });
  F(9); T(`SELECT TRACK ${lane + 1} · ALGO LEVEL`, 120, 224, LCD.muted, "center");
}
function drawParameterPage(params) {
  const F = (px) => { c.font = `${px}px ${DOT}`; };
  const T = (s, x, y, color = LCD.primary, align = "left", maxWidth = 240) => { c.fillStyle = color; c.textAlign = align; c.fillText(String(s), x, y, maxWidth); };
  if (focusedParamSlot >= 0 && focusedParamSlot < params.length) {
    const slot = focusedParamSlot, pi = params[slot], value = parameterValue(lane, pi);
    c.fillStyle = LCD.knobBg; c.fillRect(3, 43, 234, 192);
    const col = slot % 2, row = Math.floor(slot / 2);
    F(10); T(String(slot + 1), col ? 232 : 8, row ? 202 : 48, LCD.knobInk, col ? "right" : "left");
    drawParameterDial(120, 118, 40, value);
    F(19); T(PARAM_LABELS[pi], 120, 174, LCD.knobInk, "center", 216);
    drawAutomationTrace(pi, 12, 218, 216, 13);
    return;
  }
  params.forEach((pi, slot) => {
    const col = slot % 2, row = Math.floor(slot / 2), left = col * 120, top = 51 + row * 86;
    const cx = left + 60, cy = top + 31, value = parameterValue(lane, pi);
    drawKnobTile(cx, cy, PARAM_LABELS[pi], slot + 1, value, col, top);
    drawAutomationTrace(pi, left + 11, top + 73, 98, 7);
  });
  F(9); T(recording ? "REC · TURN 1–4" : "TURN KNOB TO FOCUS", 120, 224, recording ? LCD.alert : LCD.muted, "center");
}
function drawHomeKnobs(F, T) {
  const controls = [
    { label: "TEMPO", value: tempo / 240 },
    { label: "SWING", value: (swing - 50) / 50 },
    { label: "CLIP", value: clip },
    { label: "PAN", value: (clampPan(pans[lane]) + 1) / 2 },
  ];
  if (focusedHomeSlot >= 0 && focusedHomeSlot < controls.length) {
    const control = controls[focusedHomeSlot], col = focusedHomeSlot % 2, row = Math.floor(focusedHomeSlot / 2);
    c.fillStyle = LCD.knobBg; c.fillRect(3, 43, 234, 192);
    drawParameterDial(120, 123, 40, control.value);
    F(19); T(control.label, 120, 178, LCD.knobInk, "center");
    F(10); T(String(focusedHomeSlot + 1), col ? 232 : 8, row ? 212 : 48, LCD.knobInk, col ? "right" : "left");
    return;
  }
  controls.forEach((control, slot) => {
    const col = slot % 2, row = Math.floor(slot / 2), left = col * 120, top = 51 + row * 86;
    drawKnobTile(left + 60, top + 31, control.label, slot + 1, control.value, col, top);
  });
  F(9); T("TURN A KNOB TO FOCUS", 120, 224, LCD.muted, "center");
}
function drawKnobTile(cx, cy, labelText, number, value, column, top) {
  const left = column * 120;
  c.fillStyle = LCD.knobBg; c.fillRect(left + 3, top, 114, 82);
  c.strokeStyle = LCD.knobEdge; c.lineWidth = 1; c.strokeRect(left + 3.5, top + 0.5, 113, 81);
  drawParameterDial(cx, cy, 19, value);
  const numberX = column ? left + 111 : left + 9;
  const align = column ? "right" : "left";
  c.font = `10px ${DOT}`; c.fillStyle = LCD.knobInk; c.textAlign = align;
  c.fillText(String(number), numberX, top + 3);
  c.font = `14px ${DOT}`; c.textAlign = "center"; c.fillStyle = LCD.knobInk;
  c.fillText(labelText, cx, top + 55, 108);
}
function drawAutomationTrace(pi, x, y, w, h) {
  const key = playing && displayPattern ? displayPattern : pat;
  const p = ensurePattern(key), points = p.automation?.[lane] || {};
  let value = p.automationBase?.[lane]?.[pi] ?? P[lane]?.[pi] ?? 0;
  const values = new Array(p.len);
  let hasAutomation = false;
  for (let step = 0; step < p.len; step++) {
    const next = points[step]?.[pi];
    if (next !== undefined && Number.isFinite(Number(next))) {
      value = clamp01(Number(next)); hasAutomation = true;
    }
    values[step] = value;
  }
  if (!hasAutomation) return;
  c.fillStyle = LCD.row; c.fillRect(x, y, w, h);
  c.strokeStyle = LCD.track; c.lineWidth = 1;
  c.beginPath(); c.moveTo(x, y + h / 2); c.lineTo(x + w, y + h / 2); c.stroke();
  c.strokeStyle = LCD.highlight; c.lineWidth = Math.max(1, h * 0.14);
  c.beginPath();
  values.forEach((v, step) => {
    const px = x + (p.len < 2 ? 0 : step * w / (p.len - 1));
    const py = y + (1 - v) * (h - 2) + 1;
    if (step === 0) c.moveTo(px, py);
    else {
      const prevY = y + (1 - values[step - 1]) * (h - 2) + 1;
      c.lineTo(px, prevY); c.lineTo(px, py);
    }
  });
  c.stroke();
  let marker = -1;
  if (playing && key === displayPattern && cur >= 0) marker = cur % p.len;
  else if (!playing && selectedPattern === key && selectedLane === lane) marker = selectedStep;
  if (marker >= 0 && marker < p.len) {
    const px = x + (p.len < 2 ? 0 : marker * w / (p.len - 1));
    c.strokeStyle = LCD.cursor; c.lineWidth = 1;
    c.beginPath(); c.moveTo(px, y - 1); c.lineTo(px, y + h + 1); c.stroke();
    c.fillStyle = LCD.cursor; c.fillRect(px - 1.5, y + h / 2 - 1.5, 3, 3);
  }
}
function drawParameterDial(cx, cy, radius, value) {
  const angle = -Math.PI * 0.75 + Math.PI * 1.5 * clamp01(value);
  c.beginPath(); c.arc(cx, cy, radius + 3, 0, Math.PI * 2);
  c.fillStyle = "#535f67"; c.fill();
  c.beginPath(); c.arc(cx, cy, radius + 1, 0, Math.PI * 2);
  const rim = c.createRadialGradient(cx - radius * 0.36, cy - radius * 0.42, radius * 0.08, cx, cy, radius + 2);
  rim.addColorStop(0, "#f0f2f2"); rim.addColorStop(0.48, "#c6cbcd"); rim.addColorStop(1, "#7a858b");
  c.fillStyle = rim; c.fill();
  c.strokeStyle = "#eef0f0"; c.lineWidth = Math.max(1, radius * 0.035); c.stroke();
  const face = c.createRadialGradient(cx - radius * 0.3, cy - radius * 0.34, radius * 0.08, cx, cy, radius * 0.78);
  face.addColorStop(0, "#e3e6e7"); face.addColorStop(0.72, "#b8bec1"); face.addColorStop(1, "#8a9499");
  c.beginPath(); c.arc(cx, cy, radius * 0.78, 0, Math.PI * 2); c.fillStyle = face; c.fill();
  c.strokeStyle = "#647078"; c.lineWidth = Math.max(1, radius * 0.04); c.stroke();
  for (let tick = 0; tick <= 8; tick++) {
    const a = -Math.PI * 0.75 + tick * Math.PI * 1.5 / 8;
    c.beginPath();
    c.moveTo(cx + Math.cos(a) * radius * 0.85, cy + Math.sin(a) * radius * 0.85);
    c.lineTo(cx + Math.cos(a) * radius * 0.95, cy + Math.sin(a) * radius * 0.95);
    c.strokeStyle = tick === Math.round(clamp01(value) * 8) ? LCD.accent : "#59656c";
    c.lineWidth = Math.max(1, radius * 0.045); c.stroke();
  }
  c.beginPath(); c.moveTo(cx, cy); c.lineTo(cx + Math.cos(angle) * radius * 0.62, cy + Math.sin(angle) * radius * 0.62);
  c.strokeStyle = "#315f88"; c.lineWidth = Math.max(2, radius * 0.09); c.lineCap = "round"; c.stroke();
  c.beginPath(); c.arc(cx, cy, radius * 0.16, 0, Math.PI * 2); c.fillStyle = "#477fa9"; c.fill();
  c.beginPath(); c.arc(cx - radius * 0.035, cy - radius * 0.04, radius * 0.065, 0, Math.PI * 2); c.fillStyle = "#e2f3fa"; c.fill();
}
function paramDisplay(i, v) {
  if (i === 0) return ["SINE", "TRI", "SAW"][Math.round(v * 2)];
  if (i === 4) return ["DECAY", "SINE", "NOISE"][Math.round(v * 2)];
  if (i === 7) return ["LP", "BP", "HP"][Math.round(v * 2)];
  if (i === 10) return ["EXP", "LIN", "MOD"][Math.round(v * 2)];
  if ([1, 8, 15].includes(i)) return `${Math.round(20 * Math.pow(1000, v))}Hz`;
  if ([2, 11].includes(i)) return `${(v * Math.pow(10, (12 * v - 7) / 5) * 19.9526).toFixed(1)}ms`;
  if ([3, 5, 12].includes(i)) return `${Math.round(10 ** (3 * v - 2) * 1000)}ms`;
  if (i === 6) return `${Math.round((v - 0.5) * 192)}st`;
  if (i === 9) return `${(0.1 * Math.pow(10, 5 * v)).toFixed(1)}`;
  if (i === 13) return `${Math.round(v * 100)}%`;
  if (i === 14) return `${Math.round(v * 100)}%`;
  if (i === 16) return `${Math.round(v * 80 - 40)}dB`;
  if (i === 17) return `${Math.round(v * 100)}%`;
  if ([18, 19, 20].includes(i)) return `${Math.round(v * 200)}%`;
  return `${Math.round(v * 100)}%`;
}
function redraw() {
  knobs.forEach(drawKnob); drawScreen();
  for (const k of keys) if (k) k.g.setAttribute("class", `keyg${k.pressed ? " held" : ""}`);
  if (S) {
    const p = ensurePattern(pat), l = p.lanes[lane] || {};
    WHITE.forEach((key, i) => {
      const step = bank * 16 + i, active = step < p.len, hit = l.Triggers?.[step] === "#", accent = l.Accents?.[step] === "#", fill = l.Fills?.[step] === "#";
      keys[key].g.setAttribute("aria-label", `Step ${step + 1}${active ? "" : " (outside pattern)"}`);
      keys[key].g.setAttribute("aria-disabled", String(!active));
      keys[key].g.setAttribute("class", `keyg${active ? step === cur ? " lit" : accent ? " green" : fill ? " fill" : hit ? " mid" : "" : ""}${keys[key].pressed ? " held" : ""}`);
      keys[key].g.setAttribute("aria-pressed", String(hit || accent || fill));
    });
    BLACK_AFTER.forEach((_, i) => {
      const g = keys[BLACK[i]].g;
      const modStep = playing && cur >= 0 ? cur % p.len : selectedModifierStep(), modLane = p.lanes[lane] || {};
      const modOn = i === 8 ? modStep >= 0 && modLane.Accents?.[modStep] === "#" : i === 9 ? modStep >= 0 && modLane.Fills?.[modStep] === "#" : false;
      const active = (i < 8 && i === lane) || (i >= 8 && modOn) || (i === 10 && Math.ceil(p.len / 16) > 1);
      g.setAttribute("class", `keyg${active ? " lit" : ""}${keys[BLACK[i]].pressed ? " held" : ""}`);
      g.setAttribute("aria-pressed", String(active));
    });
  }
  buttons.forEach((b) => {
    const name = b.name;
    const active = (name === "PLAY" && playing) || (name === "REC" && recording) ||
      (name === "HOME" && screen === "global") || (name === "SEQ" && screen === "home") ||
      (name === "GLO" && (screen === "device" || screen === "mixer")) || (name === "FX" && screen === "fx") ||
      (name === "SEL" && screen === "scl") || (name === "ENV" && screen === "env") ||
      (name === "LFO" && screen === "lfo") || (name === "EDIT" && ["edit", "lfo", "scl", "env", "fx"].includes(screen));
    b.g.classList.toggle("lit", active);
    b.g.classList.toggle("green", name === "PLAY" && playing);
    b.g.classList.toggle("dirty", name === "SAVE" && settingsDirty);
  });
}

/* Preset and project handling */
function loadPreset(text, name = "Imported preset") {
  try {
    const next = parseTonicPreset(text);
    if (!next.drums || next.drums.length < 8) throw new Error("expected eight drum patches");
    for (let i = 0; i < 8; i++) next.drums[i] = { ...DEFAULT_PATCH, ...(next.drums[i] || {}) };
    if (!Object.keys(next.pats || {}).length) next.pats.a = { len: 16, chained: false, lanes: [] };
    S = next;
    for (const slot of PATTERN_SLOTS) if (!S.pats[slot]) S.pats[slot] = { len: 16, chained: false, lanes: [] };
    pat = next.meta.Pattern || patternKeys()[0] || "a"; if (!S.pats[pat]) pat = patternKeys()[0];
    lane = 0; bank = 0; recording = false; selectedStep = -1; selectedLane = -1; selectedPattern = ""; tempo = Math.max(40, Math.min(240, +next.meta.Tempo || 120));
    const presetSwing = Number(next.meta.Swing);
    swing = 50 + (Number.isFinite(presetSwing) ? Math.max(0, Math.min(50, presetSwing)) : 0);
    P = next.drums.map((d) => patchFromPreset(d, false));
    pans = next.drums.map((d) => clampPan(Number(d.Pan || 0) / 100));
    for (const k of patternKeys()) ensurePattern(k);
    stop(); screen = "global"; busy = true; $("#start").hidden = true; ensureAudio();
    renderAll(); saveLocal(); redraw(); message(`Loaded ${next.meta.Name || name}. Click a drum key or press PLAY.`);
  } catch (err) {
    message(`Could not read preset: ${err.message}`);
    $("#start").hidden = false;
  }
}
function syncPatch(d) {
  const p = P[d], old = S.drums[d] || { ...DEFAULT_PATCH };
  Object.assign(old, patchToPreset(p)); old.Pan = nstr(clampPan(pans[d]) * 100); S.drums[d] = old;
}
function nstr(v) { return Number.isFinite(v) ? String(+v.toPrecision(9)) : "0"; }
function attackMs(v) { return v <= 0 ? 0 : v * Math.pow(10, (12 * v - 7) / 5) * 19.95262315; }
function decayMs(v) { return 10 ** (3 * v - 2) * 1000; }
function freq(v) { return 20 * Math.pow(1000, v); }
function patchToPreset(p) {
  const wave = ["Sine", "Triangle", "Saw"][Math.round(p[0] * 2)];
  const mod = ["Decay", "Sine", "Noise"][Math.round(p[4] * 2)];
  const fil = ["LP", "BP", "HP"][Math.round(p[7] * 2)];
  const env = ["Exp", "Linear", "Mod"][Math.round(p[10] * 2)];
  let rate = mod === "Decay" ? decayMs(p[5]) : mod === "Sine" ? 2000 * p[5] : freq(p[5]);
  if (mod === "Decay" && p[5] === 0) rate = "inf";
  const scale = env === "Linear" ? 1.5 : 1;
  const level = p[17] <= 0 ? "-inf" : nstr(60 * p[17] - 49 - 1 / p[17]);
  return {
    OscWave: wave, OscFreq: nstr(freq(p[1])), OscAtk: nstr(attackMs(p[2])), OscDcy: nstr(decayMs(p[3])),
    ModMode: mod, ModRate: typeof rate === "string" ? rate : nstr(rate), ModAmt: nstr((p[6] - 0.5) * 192),
    NFilMod: fil, NFilFrq: nstr(freq(p[8])), NFilQ: nstr(0.1 * 10 ** (5 * p[9])),
    NEnvMod: env, NEnvAtk: nstr(attackMs(p[11]) / scale), NEnvDcy: nstr(decayMs(p[12]) / scale),
    Mix: nstr((1 - p[13]) * 100), DistAmt: nstr(p[14] * 100), EQFreq: nstr(freq(p[15])), EQGain: nstr(p[16] * 80 - 40),
    Level: level, OscVel: nstr(p[18] * 200), NVel: nstr(p[19] * 200), ModVel: nstr(p[20] * 200),
  };
}
function quote(s) { return `"${String(s).replaceAll("\\", "\\\\").replaceAll('"', '\\"')}"`; }
function download(name, text, type = "text/plain") {
  const a = document.createElement("a"), url = URL.createObjectURL(new Blob([text], { type }));
  a.href = url; a.download = name; a.click(); setTimeout(() => URL.revokeObjectURL(url), 1500);
}
function serializePreset() {
  if (!S) return "";
  for (let d = 0; d < 8; d++) syncPatch(d);
  const presetPattern = SAVE_PATTERN_SLOTS.includes(pat) ? pat : "a";
  S.meta.Tempo = nstr(tempo); S.meta.Swing = nstr(swing - 50); S.meta.Pattern = presetPattern;
  const lines = ["MicroTonicPresetV3: {", `\tName = ${quote(S.meta.Name || "FM1 Tonic")}`, `\tPattern = ${presetPattern}`, `\tStepRate = ${S.meta.StepRate || "1/16"}`, `\tSwing = ${nstr(swing - 50)}`, `\tTempo = ${nstr(tempo)}`, "\tMutes: { Off, Off, Off, Off, Off, Off, Off, Off }", "\tDrumPatches: {"];
  const patchFields = ["Name", "OscWave", "OscFreq", "OscAtk", "OscDcy", "ModMode", "ModRate", "ModAmt", "NFilMod", "NFilFrq", "NFilQ", "NEnvMod", "NEnvAtk", "NEnvDcy", "Mix", "DistAmt", "EQFreq", "EQGain", "Level", "OscVel", "NVel", "ModVel", "NStereo", "Output", "Pan"];
  for (let d = 0; d < 8; d++) {
    const patch = S.drums[d]; lines.push(`\t\t${d + 1}: {`);
    for (const key of patchFields) if (patch[key] !== undefined) {
      const val = String(patch[key]);
      lines.push(`\t\t\t${key} = ${/["\\\n]/.test(val) || key === "Name" || key === "OscWave" || key === "ModMode" || key === "NFilMod" || key === "NEnvMod" || key === "NStereo" || key === "Output" ? quote(val) : val}`);
    }
    lines.push("\t\t}");
  }
  lines.push("\t}", "\tPatterns: {");
  for (const key of patternKeys().filter((k) => SAVE_PATTERN_SLOTS.includes(k))) {
    const p = ensurePattern(key); lines.push(`\t\t${key}: {`, `\t\t\tChained = ${p.chained ? "true" : "false"}`, `\t\t\tLength = ${p.len}`);
    for (let d = 0; d < 8; d++) {
      const l = p.lanes[d] || {}, pad = (x) => (x || "").padEnd(p.len, "-").slice(0, p.len);
      lines.push(`\t\t\t${d + 1}: {`, `\t\t\t\tAccents = ${pad(l.Accents)}`, `\t\t\t\tFills = ${pad(l.Fills)}`, `\t\t\t\tTriggers = ${pad(l.Triggers)}`, "\t\t\t}");
    }
    lines.push("\t\t}");
  }
  lines.push("\t}", "}");
  return lines.join("\n") + "\n";
}
function downloadPreset() { if (!S) return; download(`${(S.meta.Name || "fm1-tonic").replace(/[^a-z0-9_-]+/gi, "-")}.mtpreset`, serializePreset()); message("Saved .mtpreset. Use Export project to include recorded automation."); }
function exportProject() {
  if (!S) return;
  const project = projectSnapshot();
  download("fm1-tonic-project.json", JSON.stringify(project, null, 2), "application/json"); message("Exported project backup, including automation.");
}
function loadProjectBackup(project, name = "project backup") {
  if (!project?.preset) throw new Error("project backup has no preset");
  loadPreset(project.preset, name);
  if (!S) return;
  if (project.patterns && typeof project.patterns === "object") Object.assign(S.pats, copyData(project.patterns));
  for (const slot of PATTERN_SLOTS) ensurePattern(slot);
  restoreAutomation(project.automation, project.automationBase);
  if (S.pats[project.pattern]) pat = project.pattern;
  if (Number.isInteger(project.lane)) lane = Math.max(0, Math.min(7, project.lane));
  if (Array.isArray(project.trackVolumes)) trackVolumes = Array.from({ length: 8 }, (_, i) => clamp01(Number(project.trackVolumes[i] ?? 1)));
  if (Number.isFinite(project.volume)) volume = clamp01(project.volume);
  if (Number.isFinite(project.clip)) clip = project.clip ? 1 : 0;
  if (Number.isFinite(project.swing)) swing = Math.max(50, Math.min(100, project.swing));
  if (["global", "device", "mixer", ...PAGE_NAMES].includes(project.page)) screen = project.page;
  setMasterGain(); redraw(); saveLocal();
}
function saveLocal() {
  try { localStorage.setItem("fm1-tonic-project", JSON.stringify({ preset: serializePreset(), patterns: S ? copyData(S.pats) : {}, automation: automationSnapshot(), automationBase: automationBaseSnapshot(), lane, pattern: pat, volume, clip, swing, trackVolumes: trackVolumes.slice() })); } catch { /* file:// may disable local storage */ }
}
function restoreLocal() {
  try {
    const saved = JSON.parse(localStorage.getItem("fm1-tonic-project") || "null");
    if (saved?.preset) {
      const savedPresetSwing = Number(parseTonicPreset(saved.preset).meta.Swing);
      loadPreset(saved.preset, "saved project");
      if (saved.patterns && typeof saved.patterns === "object") Object.assign(S.pats, copyData(saved.patterns));
      for (const slot of PATTERN_SLOTS) ensurePattern(slot);
      restoreAutomation(saved.automation, saved.automationBase);
      lane = saved.lane || 0; pat = S.pats[saved.pattern] ? saved.pattern : pat; volume = saved.volume ?? volume; clip = saved.clip ?? clip;
      if (Array.isArray(saved.trackVolumes)) trackVolumes = Array.from({ length: 8 }, (_, i) => clamp01(Number(saved.trackVolumes[i] ?? 1)));
      swing = Number.isFinite(saved.swing) ? Math.max(50, Math.min(100, saved.swing)) : Number.isFinite(savedPresetSwing) ? (savedPresetSwing >= 50 ? Math.min(100, savedPresetSwing) : 50 + Math.max(0, savedPresetSwing)) : 50;
      redraw(); saveLocal(); return true;
    }
  } catch { /* bad or unavailable local storage */ }
  return false;
}

/* Audio */
function ensureAudio() {
  if (ctx) return;
  ctx = new AudioContext({ sampleRate: 44100 });
  master = ctx.createGain(); setMasterGain();
  outputGainNode = ctx.createGain(); setOutputGain();
  shaper = ctx.createWaveShaper();
  updateShaper(); master.connect(shaper); shaper.connect(outputGainNode); outputGainNode.connect(ctx.destination);
}
function updateShaper() {
  if (!shaper) return;
  const drive = clip ? 2 : 1.25, curve = new Float32Array(2049);
  for (let i = 0; i < curve.length; i++) curve[i] = Math.tanh((i / 1024 - 1) * drive) / Math.tanh(drive);
  shaper.curve = curve;
}
function makeAudioBuffer(d, patch = P[d], assign = true) {
  if (!ctx || !patch) return null;
  const two = [96, 127].map((vel) => {
    const data = render(patch, vel, 3, 44100, 1), n = data.length;
    for (let i = 0; i < Math.min(2205, n); i++) data[n - 1 - i] *= i / 2205;
    const b = ctx.createBuffer(1, n, 44100); b.copyToChannel(data, 0); return b;
  });
  if (assign) bufs[d] = two;
  return two;
}
function renderAll() {
  if (!ctx || !S) { busy = false; return; }
  for (let d = 0; d < 8; d++) makeAudioBuffer(d);
  busy = false; redraw();
}
function renderLane(d) { if (ctx && S) makeAudioBuffer(d); saveLocal(); }
function trig(d, time, accent, sourceBuffers = bufs[d]) {
  if (!sourceBuffers || busy || !ctx) return;
  try {
    const old = voices[d]; if (old) { old.g.gain.setTargetAtTime(0, time, 0.002); old.s.stop(time + 0.02); }
    const s = ctx.createBufferSource(), g = ctx.createGain(), panner = ctx.createStereoPanner();
    s.buffer = sourceBuffers[accent ? 1 : 0]; g.gain.value = 0.82 * (trackVolumes[d] ?? 1);
    panner.pan.value = clampPan(pans[d]); s.connect(g); g.connect(panner); panner.connect(master);
    s.start(time); voices[d] = { s, g, panner };
  } catch { /* a voice may already have stopped at the end of its tail */ }
}
function updateVoicePan(d) {
  const panner = voices[d]?.panner;
  if (panner && ctx) panner.pan.setTargetAtTime(clampPan(pans[d]), ctx.currentTime, 0.01);
}
function applyStepAutomation(p, step, d) {
  if (step === 0) {
    const base = p.automationBase?.[d] || P[d];
    if (base && playbackPatches[d]) {
      playbackPatches[d] = base.slice();
      playbackBuffers[d] = playbackPatches[d].every((value, i) => value === P[d][i])
        ? bufs[d] : makeAudioBuffer(d, playbackPatches[d], false) || bufs[d];
    }
  }
  const values = p.automation?.[d]?.[step];
  if (!values || !playbackPatches[d]) return;
  let changed = false;
  for (const [indexText, value] of Object.entries(values)) {
    const index = Number(indexText), next = clamp01(Number(value));
    if (Number.isInteger(index) && index >= 0 && index < PARAM_NAMES.length && playbackPatches[d][index] !== next) {
      playbackPatches[d][index] = next; changed = true;
    }
  }
  if (changed) playbackBuffers[d] = makeAudioBuffer(d, playbackPatches[d], false) || bufs[d];
}
function preparePlaybackPattern(key) {
  const p = ensurePattern(key);
  playbackPattern = key;
  playbackPatches = P.map((patch, d) => (p.automationBase?.[d] || patch).slice());
  playbackBuffers = playbackPatches.map((patch, d) =>
    patch.every((value, i) => value === P[d][i]) ? bufs[d] : makeAudioBuffer(d, patch, false) || bufs[d]);
}
function prepareDisplayPattern(key) {
  const p = ensurePattern(key);
  displayPattern = key;
  displayPatches = P.map((patch, d) => (p.automationBase?.[d] || patch).slice());
}
function applyDisplayAutomation(key, step) {
  if (displayPattern !== key) prepareDisplayPattern(key);
  const p = ensurePattern(key);
  if (step === 0) {
    for (let d = 0; d < 8; d++)
      displayPatches[d] = (p.automationBase?.[d] || P[d]).slice();
  }
  for (let d = 0; d < 8; d++) {
    const values = p.automation?.[d]?.[step];
    if (!values) continue;
    for (const [indexText, value] of Object.entries(values)) {
      const index = Number(indexText);
      if (Number.isInteger(index) && index >= 0 && index < PARAM_NAMES.length)
        displayPatches[d][index] = clamp01(Number(value));
    }
  }
}
function audition(d) {
  if (!S || busy) return;
  ensureAudio(); ctx.resume(); lane = d; trig(d, ctx.currentTime + 0.01, true);
  if (recording && playing) { const step = stp % ensurePattern(pat).len; bank = Math.floor(step / 16); toggleStep(step % 16, null); }
  else message(`Auditioning TRACK ${d + 1}.`);
  redraw();
}
function tick() {
  if (!S || !ctx) return;
  const stepDur = 60 / tempo / 4;
  while (nxt < ctx.currentTime + 0.12) {
    if (playbackPattern !== pat) preparePlaybackPattern(pat);
    const p = ensurePattern(pat), s = stp % p.len, t = nxt + (s % 2 ? ((swing - 50) / 100) * stepDur : 0);
    for (let d = 0; d < 8; d++) {
      const l = p.lanes[d];
      if (!l) continue;
      applyStepAutomation(p, s, d);
      const source = playbackBuffers[d] || bufs[d], accent = l.Accents?.[s] === "#";
      if (l.Triggers?.[s] === "#" && l.Fills?.[s] === "#") {
        const swingOffset = (swing - 50) / 100 * stepDur;
        const interval = stepDur + ((s + 1) % 2 ? swingOffset : 0) - (s % 2 ? swingOffset : 0);
        for (let repeat = 0; repeat < 4; repeat++) trig(d, t + interval * repeat / 4, accent, source);
      } else if (l.Triggers?.[s] === "#") trig(d, t, accent, source);
    }
    q.push([t, s, pat]); stp++; nxt += stepDur;
    if (stp % p.len === 0 && p.chained) {
      const ks = patternKeys(), ix = ks.indexOf(pat); pat = ks[(ix + 1) % ks.length];
    }
  }
}
function raf() {
  if (!playing) return;
  let event = null; while (q.length && q[0][0] <= ctx.currentTime) event = q.shift();
  if (event) {
    const [, step, key] = event;
    cur = step; bank = Math.floor(step / 16); applyDisplayAutomation(key || pat, step); redraw();
  }
  requestAnimationFrame(raf);
}
function play() {
  if (!S || playing || busy) return;
  ensureAudio(); ctx.resume(); preparePlaybackPattern(pat); prepareDisplayPattern(pat);
  playing = true; stp = 0; q = []; nxt = ctx.currentTime + 0.08;
  timer = setInterval(tick, 25); tick(); raf(); redraw();
}
function stop() {
  playing = false; clearInterval(timer); timer = 0; q = []; cur = -1;
  for (const v of voices) if (v) { try { v.s.stop(); } catch { /* already ended */ } }
  voices = []; playbackPatches = []; playbackBuffers = []; playbackPattern = ""; displayPatches = []; displayPattern = ""; redraw();
}

function wav(samples, rate = 44100) {
  const n = samples.length, b = new DataView(new ArrayBuffer(44 + n * 2));
  const w = (i, s) => [...s].forEach((ch, j) => b.setUint8(i + j, ch.charCodeAt(0)));
  w(0, "RIFF"); b.setUint32(4, 36 + n * 2, true); w(8, "WAVEfmt "); b.setUint32(16, 16, true); b.setUint16(20, 1, true); b.setUint16(22, 1, true);
  b.setUint32(24, rate, true); b.setUint32(28, rate * 2, true); b.setUint16(32, 2, true); b.setUint16(34, 16, true); w(36, "data"); b.setUint32(40, n * 2, true);
  let peak = 0; for (const x of samples) peak = Math.max(peak, Math.abs(x)); const gain = peak > 1 ? 0.98 / peak : 1;
  for (let i = 0; i < n; i++) b.setInt16(44 + i * 2, Math.round(Math.max(-1, Math.min(1, samples[i] * gain)) * 32767), true);
  return new Blob([b], { type: "audio/wav" });
}
function downloadWav() {
  if (!S) return;
  const data = render(P[lane], 127, 3, 44100, 1), url = URL.createObjectURL(wav(data));
  const a = document.createElement("a"); a.href = url; a.download = `tonic-drum${lane + 1}.wav`; a.click(); setTimeout(() => URL.revokeObjectURL(url), 1500);
}

$("#go").addEventListener("click", () => { ensureAudio(); ctx.resume(); if (!restoreLocal()) loadPreset(DEMO, "demo preset"); });
$("#demo").addEventListener("click", () => { ensureAudio(); loadPreset(DEMO, "demo preset"); });
$("#file").addEventListener("change", async (e) => {
  const f = e.target.files?.[0]; if (!f) return;
  try {
    const text = await f.text();
    if (f.name.toLowerCase().endsWith(".json")) {
      loadProjectBackup(JSON.parse(text));
    } else loadPreset(text, f.name);
  } catch (err) { message(`Could not open file: ${err.message}`); }
  e.target.value = "";
});
$("#save").addEventListener("click", downloadPreset);
$("#project").addEventListener("click", exportProject);
$("#wav").addEventListener("click", downloadWav);
addEventListener("dragover", (e) => e.preventDefault());
addEventListener("drop", async (e) => {
  e.preventDefault(); const f = e.dataTransfer?.files?.[0]; if (!f) return;
  try {
    const text = await f.text();
    if (f.name.toLowerCase().endsWith(".json")) loadProjectBackup(JSON.parse(text));
    else loadPreset(text, f.name);
  } catch (err) { message(`Could not open file: ${err.message}`); }
});
addEventListener("keydown", (e) => {
  if (e.code === "Space" && !e.target.closest("button,label")) { e.preventDefault(); playing ? stop() : play(); }
  else if (/^Digit[1-8]$/.test(e.code)) audition(+e.code[5] - 1);
  else if (e.code === "BracketLeft") transpose(-1);
  else if (e.code === "BracketRight") transpose(1);
});
restoreDeviceSettings();
build(); redraw();
if (document.fonts?.load) document.fonts.load("16px DotGothic16").then(redraw);

function parseTonicPreset(text) {
  const parsed = parsePreset(text);
  let inPatterns = false, current = "", indent = 0;
  for (const raw of text.replace(/\r/g, "").split("\n")) {
    const line = raw.trim(), ws = raw.match(/^[\t ]*/)[0].length;
    if (line === "Patterns: {") { inPatterns = true; continue; }
    if (!inPatterns) continue;
    const start = /^([a-l]):\s*\{$/.exec(line);
    if (start) { current = start[1]; indent = ws; continue; }
    if (!current) continue;
    const chain = /^Chained\s*=\s*(true|false)\s*$/i.exec(line);
    if (chain && parsed.pats[current]) parsed.pats[current].chained = chain[1].toLowerCase() === "true";
    if (line === "}" && ws === indent) current = "";
  }
  return parsed;
}
