/* JS port of libpo32 (MIT, Eric Lewis): synth + .mtdrum import, float32-faithful. Needs SINE, EXP2, LOG2 tables. */
const F=Math.fround,T=Math.trunc,fb=new Float32Array(1),ub=new Uint32Array(fb.buffer);
const TWO_PI=F(6.28318530717958647692),HALF_PI=F(1.57079632679489661923),TH=F(1/3),TT=F(2/3);
function sinT(idx){let i0=T(idx),fr=F(idx-i0);i0&=2047;return F(SINE[i0]+F(fr*F(SINE[(i0+1)&2047]-SINE[i0])))}
function sinf(r){let i=F(r*F(2048*F(0.15915494309189533577)));i=F(i-F(2048*T(F(i*F(1/2048)))));if(i<0)i=F(i+2048);return sinT(i)}
const cosf=r=>sinf(F(r+HALF_PI));
function exp2(x){if(x<-126)return 0;if(x>127)return 3.4028234663852886e38;let ip=T(x);if(x<ip)ip--;const fs=F(F(x-ip)*1024);let i0=T(fs);const fr=F(fs-i0);let a,b;if(i0>=1023){i0=1023;a=EXP2[1023];b=2}else{a=EXP2[i0];b=EXP2[i0+1]}return F(F(a+F(fr*F(b-a)))*Math.pow(2,ip))}
function log2(x){if(x<=0)return -126;fb[0]=x;const u=ub[0],e=((u>>>23)&255)-127,fs=F(F(u&0x7fffff)*F(1024/8388608));let i0=T(fs);const fr=F(fs-i0);if(i0>=1023){const t=LOG2[1023];return F(F(e+t)+F(fr*F(1-t)))}const a=LOG2[i0],b=LOG2[i0+1];return F(F(e+a)+F(fr*F(b-a)))}
const powf=(b,e)=>b<=0?0:exp2(F(e*log2(b))),expf=x=>exp2(F(x*F(1.44269504088896340736))),pow10=x=>exp2(F(x*F(3.32192809488736234787)));
const logf=x=>F(log2(x)*F(0.69314718055994530942)),log10=x=>F(log2(x)*F(0.30102999566398119521));
function sqrtq(x){if(x<=0)return 0;const h=F(x*.5);fb[0]=x;ub[0]=(0x5F375A86-(ub[0]>>>1))>>>0;let y=fb[0];y=F(y*F(1.5-F(F(h*y)*y)));y=F(y*F(1.5-F(F(h*y)*y)));return F(x*y)}
const cl=(x,l,h)=>x<l?l:x>h?h:x,ab=Math.abs,c01=x=>cl(x,0,1);
const db2g=db=>pow10(F(db/20)),pExp=(x,mn,mx)=>F(mn*powf(F(mx/mn),x)),pHz=x=>pExp(x,20,20000);
const attack=x=>x<=0?0:F(F(x*F(0.01995262315))*pow10(F(F(12/5)*x))),decay=x=>pExp(x,F(0.01),10);
const levelG=l=>{if(l<F(1e-4))return 0;const db=F(F(F(60*l)-49)-F(1/l));return db<-500?0:db2g(db)};
const velG=(v,s)=>{const x=cl(F(1-F(F(F(127-v)/63)*s)),0,1);return F(x*db2g(F(37*F(x-1))))};
const mixO=m=>{const p=F(F(m*2)-1);return p<0?1:F(F(1-p)*db2g(F(-25*p)))},mixN=m=>{const p=F(F(m*2)-1);return p>=0?1:F(F(1+p)*db2g(F(25*p)))};
const symL=x=>F(.5*F(ab(F(x+1))-ab(F(x-1))));
function distort(x,am){const dr=F(200*F(F(F(am*am)*am)));if(dr<=0)return x;const C=F(1/3);
 if(dr<1){const g=F(1-F(dr*F(1/30))),lim=F(F(1+sqrtq(F(F(dr+3)/dr)))*C),dc=F(F(F(-2/27)*dr)+F(-9/27));let xc=cl(F(x-C),-lim,lim);return F(F(F(xc*F(F(dr*F(ab(xc)-F(xc*xc)))+1))-dc)*g)}
 const g=F(F(F(0.2)/F(dr-F(0.4827586)))+F(0.58)),k=F(-11/27),h=(v)=>{const xc=symL(v);return F(F(xc*F(F(F(ab(xc)-F(xc*xc))+1)))-k)};
 return F(F(.5*F(h(F(F(x*dr)-C))-h(F(F(-x*dr)-C))))*g)}
function bq(type,f,q,sr,gdb){const w=F(F(TWO_PI*f)/sr),s=sinf(w),c=cosf(w);let b0,b1,b2,a1,a2,a0;
 if(type==='pk'){const A=pow10(F(gdb/40)),al=F(s*.5);a0=F(1+F(al/A));b0=F(F(1+F(al*A))/a0);b1=F(F(-2*c)/a0);b2=F(F(1-F(al*A))/a0);a1=b1;a2=F(F(1-F(al/A))/a0)}
 else{const al=F(s/F(2*q));a0=F(1+al);a1=F(F(-2*c)/a0);a2=F(F(1-al)/a0);
  if(type==='lp'){b0=F(F(F(1-c)*.5)/a0);b1=F(F(1-c)/a0);b2=b0}else if(type==='bp'){b0=F(al/a0);b1=0;b2=F(-al/a0)}else{b0=F(F(F(1+c)*.5)/a0);b1=F(F(-F(1+c))/a0);b2=b0}}
 return{b0,b1,b2,a1,a2,z1:0,z2:0}}
function bqp(f,x){const o=F(F(f.b0*x)+f.z1);f.z1=F(F(F(f.b1*x)-F(f.a1*o))+f.z2);f.z2=F(F(f.b2*x)-F(f.a2*o));return o}
/* P: Float32Array(21): OscWave OscFreq OscAtk OscDcy ModMode ModRate ModAmt NFilMod NFilFrq NFilQ NEnvMod NEnvAtk NEnvDcy Mix DistAmt EQFreq EQGain Level OscVel NVel ModVel */
function render(P,vel,dur,sr0=44100,clip=0){const sr=F(sr0),inv=F(1/sr),n=T(F(sr*dur)),out=new Float32Array(n);
 const[W,OF,OA,OD,MM,MR,MA,NM,NF,NQ,NE,NA,ND,MX,DI,EF,EG,LV,OV,NV,MV]=P;
 const mx=F(sr*F(0.45)),osF=F(pHz(OF)*inv),oAtk=attack(OA),oDcy=decay(OD);let sm=F(F(MA-.5)*192);
 const nf=bq(NM<TH?'lp':NM<TT?'bp':'hp',Math.min(pHz(NF),mx),pExp(NQ,F(.1),10000),sr),nAtk=attack(NA),nDcy=decay(ND);
 const eqDb=F(F(EG-.5)*80),useEq=ab(eqDb)>F(.5),ef=useEq?bq('pk',Math.min(pHz(EF),mx),0,sr,eqDb):null;
 const lvl=levelG(LV),gO=F(mixO(MX)),gN=F(mixN(MX)),vO=velG(vel,OV),vN=velG(vel,NV);sm=F(sm*velG(vel,MV));
 const mDt=decay(MR),mrh=MM<TT?F(2000*MR):pHz(MR);let al=cl(F(1-expf(F(F(-TWO_PI*mrh)/sr))),F(.001),1);const oma=F(1-al);
 const wave=W<TH?0:W<TT?1:2,mExp=MM<TH,mSin=!mExp&&MM<TT,ring=NE>TT,lin=!ring&&NE>TH;
 const pSc=F(sm*F(1/12)),pAct=pSc!==0,oIn=oAtk>0,oAc=oIn?powf(1000,F(inv/oAtk)):1,oDc=powf(F(.001),F(inv/oDcy));
 const nIn=nAtk>0,nAc=nIn?powf(1000,F(inv/nAtk)):1,nDc=powf(F(.001),F(inv/nDcy));
 const lA=F(nAtk*TT),lD=F(nDcy*TT),iLA=lA>0?F(1/lA):0,iLD=F(1/lD),mDc=powf(F(.001),F(inv/mDt));
 let rs,rc;{const q=F(F(TWO_PI*mrh)*inv*.125),q2=F(q*q),s=F(q*F(1+F(q2*F(F(-1/6)+F(q2*F(F(1/120)+F(q2*F(-1/5040)))))))),c=F(1+F(q2*F(-.5+F(q2*F(F(1/24)+F(q2*F(-1/720))))))),s2=F(2*s*c),c2=F(F(c*c)-F(s*s)),s4=F(2*s2*c2),c4=F(F(c2*c2)-F(s2*s2));rs=F(2*s4*c4);rc=F(F(c4*c4)-F(s4*s4))}
 let mP=0,mAmp=1,mPer=0;if(ring&&ND>F(1e-4)){mPer=F(F(ND/sr)*powf(10000,ND));if(mPer<F(1.5e-3)){mPer=F(mPer*8);mAmp=sqrtq(F(.5/mPer))}else mPer=F(mPer*2)}
 const iMP=mPer>0?F(1/mPer):0;
 let ph=0,mSt=0,rnd=123456789,oe=F(.001),oSy=0,ne=F(.001),nSy=0,me=1,ms=0,mc=1;
 for(let i=0;i<n;i++){const t=F(i*inv);let oenv,nenv,msig;
  if(oIn&&t<oAtk){oenv=oe;oe=F(oe*oAc)}else{if(!oSy){oe=powf(F(.001),F(F(t-oAtk)/oDcy));oSy=1}oenv=oe;oe=F(oe*oDc)}
  if(mExp){msig=me;me=F(me*mDc)}else if(mSin){const s2=F(F(ms*rc)+F(mc*rs)),c2=F(F(mc*rc)-F(ms*rs));msig=F(ms*me);ms=s2;mc=c2;me=F(me*mDc)}
  else{rnd=(Math.imul(rnd,1103515245)+12345)>>>0;const r=F(F((rnd&0x7fffffff)*F(1/F(2147483647)))*2-1);mSt=F(F(mSt*oma)+F(r*al));msig=mSt}
  const fm=pAct?exp2(F(msig*pSc)):1;ph=F(ph+F(osF*fm));ph=F(ph-T(ph));if(ph<0)ph=F(ph+1);
  let os=wave===0?sinT(F(ph*2048)):wave===1?F(F(2*ab(F(F(2*ph)-1)))-1):F(F(2*ph)-1);os=F(os*oenv);
  if(ring){if(t<nAtk)nenv=1;else{const dt=F(t-nAtk);if(!nSy){ne=powf(F(.001),F(dt/nDcy));nSy=1}const d=ne;ne=F(ne*nDc);
    if(mPer>0){let sw=F(F(dt*iMP));sw=F(sw-T(sw));if(sw<0)sw=F(sw+1);const tri=F(1-F(2*ab(F(sw-.5))));nenv=F(F(cosf(F(F(3.14159265358979323846)*tri))*d)*mAmp)}else nenv=d}}
  else if(lin){nenv=t<lA?F(t*iLA):t<F(lA+lD)?F(1-F(F(t-lA)*iLD)):0}
  else{if(nIn&&t<nAtk){nenv=ne;ne=F(ne*nAc)}else{if(!nSy){ne=powf(F(.001),F(F(t-nAtk)/nDcy));nSy=1}nenv=ne;ne=F(ne*nDc)}}
  rnd=(Math.imul(rnd,1103515245)+12345)>>>0;const nr=F(F((rnd&0x7fffffff)*F(1/F(2147483647)))*2-1);
  const ns=F(bqp(nf,nr)*nenv);let s=F(F(F(os*gO)*vO)+F(F(ns*gN)*vN));
  if(DI>F(.01))s=distort(s,DI);if(useEq)s=bqp(ef,s);s=F(s*lvl);out[i]=clip?s:(s>1?1:s<-1?-1:s)}
 return out}
/* ---- importer (preset units -> normalized), float32-faithful strtof ---- */
function strtof(s){let p=0,sg=1,r=0,fr=0,fd=1,g=0,nz=0;if(s[p]==='-'){sg=-1;p++}else if(s[p]==='+')p++;
 while(s[p]>='0'&&s[p]<='9'){const d=+s[p++];r=F(F(r*10)+d);g=1;if(d)nz=1}
 if(s[p]==='.'){p++;while(s[p]>='0'&&s[p]<='9'){const d=+s[p++];fd=F(fd*10);fr=F(fr+F(d/fd));g=1;if(d)nz=1}}
 r=F(sg*F(r+fr));if(g&&(s[p]==='e'||s[p]==='E')){p++;let es=1,ex=0,h=0;if(s[p]==='-'){es=-1;p++}else if(s[p]==='+')p++;while(s[p]>='0'&&s[p]<='9'){h=1;ex=Math.min(100,ex*10+ +s[p++])}
  if(h){if(es>0)r=ex>38?(nz?sg*3.4028234663852886e38:r):F(r*pow10(ex));else r=ex>45?0:ex>38?F(F(r/pow10(38))/pow10(ex-38)):F(r/pow10(ex))}}return r}
const num=v=>{const m=/^[-+0-9.eE]+/.exec(v.trim());if(!m)throw Error('bad number '+v);return strtof(m[0])};
const hz2p=h=>c01(F(logf(F(h/20))/logf(1000))),dms2p=ms=>c01(F(F(log10(F(ms/1000))+2)/3));
function atk2p(ms){if(ms<=0)return 0;const s=F(ms/1000);let lo=0,hi=1;for(let i=0;i<32;i++){const m=F(F(lo+hi)*.5),pr=m===0?0:F(m*pow10(F(F(F(12*m)-7)/5)));if(pr<s)lo=m;else hi=m}return c01(F(F(lo+hi)*.5))}
function lvl2p(db){if(db<=-500)return 0;let lo=F(1e-4),hi=1;for(let i=0;i<40;i++){const m=F(F(lo+hi)*.5),pr=F(F(F(60*m)-49)-F(1/m));if(pr<db)lo=m;else hi=m}return c01(F(F(lo+hi)*.5))}
/* kv: preset drum-patch key/values (strings). mixIsNoise: read Mix as noise share instead of libpo32's osc share */
function patchFromPreset(kv,mixIsNoise){const P=new Float32Array(21),g=k=>kv[k];
 P[0]=/^Sine/.test(g('OscWave'))?0:/^Tri/.test(g('OscWave'))?.5:1;P[1]=hz2p(num(g('OscFreq')));P[2]=atk2p(num(g('OscAtk')));P[3]=dms2p(num(g('OscDcy')));
 const mm=g('ModMode');P[4]=/^Decay/.test(mm)?0:/^Sine/.test(mm)?.5:1;const mr=g('ModRate');
 P[5]=P[4]===0?(/^inf/i.test(mr)?0:dms2p(num(mr))):P[4]===.5?c01(F(num(mr)/2000)):(num(mr)===0?0:hz2p(num(mr)));
 P[6]=c01(F(F(num(g('ModAmt'))/192)+.5));const nf=g('NFilMod');P[7]=/^LP/.test(nf)?0:/^BP/.test(nf)?.5:1;P[8]=hz2p(num(g('NFilFrq')));P[9]=c01(F(log10(F(num(g('NFilQ'))/F(.1)))/5));
 const ne=g('NEnvMod');P[10]=/^Exp/.test(ne)?0:/^Lin/.test(ne)?.5:1;const k=P[10]===.5?F(1.5):1;P[11]=atk2p(F(num(g('NEnvAtk'))*k));P[12]=dms2p(F(num(g('NEnvDcy'))*k));
 const mx=+g('Mix'),lead=num((mixIsNoise?100-mx:mx).toFixed(9));P[13]=c01(F(1-F(lead/100)));P[14]=c01(F(num(g('DistAmt'))/100));P[15]=hz2p(num(g('EQFreq')));P[16]=c01(F(F(num(g('EQGain'))+40)/80));
 P[17]=/^-inf/i.test(g('Level'))?0:lvl2p(num(g('Level')));P[18]=c01(F(num(g('OscVel'))/200));P[19]=c01(F(num(g('NVel'))/200));P[20]=c01(F(num(g('ModVel'))/200));return P}
/* ---- .mtpreset parser ---- */
function parsePreset(txt){const L=txt.replace(/\r/g,'').split('\n'),o={meta:{},drums:[],pats:{}};let sec=0,d=-1,p=null,ln=-1;
 for(let raw of L){const l=raw.trim();if(!l)continue;if(l==='DrumPatches: {'){sec=1;continue}if(l==='Patterns: {'){sec=2;continue}
  const eq=l.indexOf(' = '),op=/^(\w+): \{$/.exec(l);const k=eq>0?l.slice(0,eq):null,v=eq>0?l.slice(eq+3).replace(/^"|"$/g,''):null;
  if(sec===0&&k)o.meta[k]=v;else if(sec===1){if(op&&/^[1-8]$/.test(op[1])){d=+op[1]-1;o.drums[d]={}}else if(k&&d>=0)o.drums[d][k]=v}
  else if(sec===2){if(op&&/^[a-l]$/.test(op[1])){p=o.pats[op[1]]={len:16,lanes:[]};ln=-1}else if(op&&/^[1-8]$/.test(op[1])&&p){ln=+op[1]-1;p.lanes[ln]={}}else if(k&&p){if(k==='Length')p.len=+v;else if(ln>=0)p.lanes[ln][k]=v}}}
 return o}
